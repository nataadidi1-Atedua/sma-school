
import React, { useState } from 'react';
import { Student, School, StaffAssiduity } from '../types';

interface DirectionViewProps {
  students: Student[];
  currentSchool: School;
  onUpdateSchool: (school: School) => void;
  onAddSchool: (school: School) => void;
}

const MOCK_STAFF_ASSIDUITY: StaffAssiduity[] = [
  { id: 'ST1', name: 'Ana Paula Lourenço', role: 'Professora Primária', presenceDays: 20, absences: 1, lateArrivals: 2, earlyDepartures: 0, justified: 1, unjustified: 0, punctualityScore: 92, globalIndex: 95, avatar: 'https://picsum.photos/seed/ana/100' },
  { id: 'ST2', name: 'Moisés Kambinda', role: 'Secretário Académico', presenceDays: 21, absences: 0, lateArrivals: 0, earlyDepartures: 1, justified: 0, unjustified: 0, punctualityScore: 100, globalIndex: 98, avatar: 'https://picsum.photos/seed/moises/100' },
  { id: 'ST3', name: 'Carlos Neto', role: 'Prof. Matemática', presenceDays: 18, absences: 3, lateArrivals: 5, earlyDepartures: 2, justified: 2, unjustified: 1, punctualityScore: 78, globalIndex: 82, avatar: 'https://picsum.photos/seed/carlos/100' },
];

const DirectionView: React.FC<DirectionViewProps> = ({ 
  students, 
  currentSchool, 
  onUpdateSchool, 
  onAddSchool 
}) => {
  const [activeMenu, setActiveMenu] = useState<'director' | 'pedagogical' | 'assiduity' | null>(null);
  const [activeForm, setActiveForm] = useState<'teacher' | 'secretary' | 'eval' | null>(null);
  
  const [isAddSchoolModalOpen, setIsAddSchoolModalOpen] = useState(false);
  const [isEditSchoolModalOpen, setIsEditSchoolModalOpen] = useState(false);
  const [schoolForm, setSchoolForm] = useState({ name: '', location: '', type: '' });

  const closeForm = () => setActiveForm(null);

  const directorCategories = [
    {
      title: "Recursos Humanos",
      color: "bg-blue-500",
      actions: [
        { label: "Adicionar Professor", icon: "fa-chalkboard-user", color: "text-blue-600", onClick: () => setActiveForm('teacher') },
        { label: "Adicionar Secretário(a)", icon: "fa-file-signature", color: "text-indigo-600", onClick: () => setActiveForm('secretary') },
        { label: "Assiduidade Staff", icon: "fa-user-clock", color: "text-cyan-600", onClick: () => setActiveMenu('assiduity') },
        { label: "Avaliação Docente", icon: "fa-ranking-star", color: "text-blue-500", onClick: () => setActiveForm('eval') },
      ]
    },
    {
      title: "Institucional",
      color: "bg-amber-500",
      actions: [
        { label: "Nova Unidade Escolar", icon: "fa-school-flag", color: "text-amber-600", onClick: () => setIsAddSchoolModalOpen(true) },
        { label: "Editar Dados Escola", icon: "fa-pen-to-square", color: "text-slate-600", onClick: () => setIsEditSchoolModalOpen(true) },
        { label: "Estatutos & Normas", icon: "fa-gavel", color: "text-amber-700", onClick: () => {} },
        { label: "Parcerias Académicas", icon: "fa-handshake", color: "text-amber-500", onClick: () => {} },
      ]
    }
  ];

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-7xl mx-auto min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Painel Institucional</h2>
          <p className="text-slate-500 text-sm italic">"SM@ School Academy Manager - Gestão de Alto Nível"</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <button 
          onClick={() => setActiveMenu(activeMenu === 'director' ? null : 'director')}
          className={`bg-white p-6 rounded-[32px] shadow-sm border text-left flex items-center gap-5 group transition-all duration-300 ${activeMenu === 'director' ? 'ring-4 ring-blue-500/10 border-blue-200' : 'hover:border-blue-500/30'}`}
        >
          <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center text-2xl shadow-lg">
            <i className="fa-solid fa-user-tie"></i>
          </div>
          <div className="flex-1">
            <h4 className="text-[10px] font-black uppercase text-blue-600 tracking-widest mb-1">Director(a) Escolar</h4>
            <p className="text-lg font-black text-slate-800">Recursos Humanos & Unidades</p>
          </div>
        </button>

        <button 
          onClick={() => setActiveMenu(activeMenu === 'assiduity' ? null : 'assiduity')}
          className={`bg-white p-6 rounded-[32px] shadow-sm border text-left flex items-center gap-5 group transition-all duration-300 ${activeMenu === 'assiduity' ? 'ring-4 ring-cyan-500/10 border-cyan-200' : 'hover:border-cyan-500/30'}`}
        >
          <div className="w-16 h-16 rounded-2xl bg-cyan-600 text-white flex items-center justify-center text-2xl shadow-lg">
            <i className="fa-solid fa-user-clock"></i>
          </div>
          <div className="flex-1">
            <h4 className="text-[10px] font-black uppercase text-cyan-600 tracking-widest mb-1">Gestão de Assiduidade</h4>
            <p className="text-lg font-black text-slate-800">Controle de Frequência Staff</p>
          </div>
        </button>
      </div>

      {activeMenu === 'director' && (
        <div className="bg-white rounded-[40px] shadow-2xl border border-blue-50 p-8 animate-in fade-in slide-in-from-top-4 duration-500">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {directorCategories.map((category, idx) => (
                <div key={idx} className="space-y-6">
                   <h5 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] border-b pb-4 flex items-center gap-3">
                     <div className={`w-2 h-2 rounded-full ${category.color}`}></div>
                     {category.title}
                   </h5>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                     {category.actions.map((action, aIdx) => (
                       <button 
                         key={aIdx} 
                         onClick={action.onClick}
                         className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:bg-slate-900 hover:text-white transition-all group"
                       >
                         <div className={`w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center group-hover:bg-slate-800 ${action.color}`}>
                            <i className={`fa-solid ${action.icon}`}></i>
                         </div>
                         <span className="text-[10px] font-black uppercase tracking-wider">{action.label}</span>
                       </button>
                     ))}
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {activeMenu === 'assiduity' && (
        <div className="bg-white rounded-[40px] shadow-2xl border border-cyan-50 overflow-hidden animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="p-8 border-b bg-cyan-50/20 flex justify-between items-center">
            <div>
              <h3 className="text-xl font-black text-slate-800 tracking-tight">Quadro de Assiduidade Semanal</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Supervisão de Punctualidade e Frequência</p>
            </div>
            <button className="px-5 py-2.5 bg-cyan-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-cyan-600/20">Exportar Relatório</button>
          </div>
          <div className="overflow-x-auto">
             <table className="w-full text-left">
                <thead className="bg-slate-50 text-[9px] font-black uppercase text-slate-400 tracking-widest">
                  <tr>
                    <th className="px-8 py-5">Funcionário</th>
                    <th className="px-6 py-5 text-center">Presenças</th>
                    <th className="px-6 py-5 text-center">Faltas (J/F)</th>
                    <th className="px-6 py-5 text-center">Atrasos</th>
                    <th className="px-6 py-5 text-center">Saídas Ant.</th>
                    <th className="px-6 py-5 text-center">Punctualidade</th>
                    <th className="px-8 py-5 text-right">Acções</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {MOCK_STAFF_ASSIDUITY.map(staff => (
                    <tr key={staff.id} className="hover:bg-cyan-50/30 transition-colors group">
                      <td className="px-8 py-5">
                        <div className="flex items-center gap-4">
                          <img src={staff.avatar} className="w-10 h-10 rounded-xl object-cover" />
                          <div>
                            <p className="text-sm font-black text-slate-800">{staff.name}</p>
                            <p className="text-[9px] text-slate-400 font-bold uppercase">{staff.role}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 text-center font-bold text-slate-600">{staff.presenceDays} dias</td>
                      <td className="px-6 py-5 text-center">
                        <span className="text-emerald-600">{staff.justified}J</span> / <span className="text-rose-600">{staff.unjustified}F</span>
                      </td>
                      <td className="px-6 py-5 text-center font-bold text-amber-600">{staff.lateArrivals}</td>
                      <td className="px-6 py-5 text-center font-bold text-slate-400">{staff.earlyDepartures}</td>
                      <td className="px-6 py-5">
                         <div className="flex flex-col items-center gap-1.5">
                            <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                               <div className={`h-full ${staff.punctualityScore > 90 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${staff.punctualityScore}%` }}></div>
                            </div>
                            <span className="text-[10px] font-black">{staff.punctualityScore}%</span>
                         </div>
                      </td>
                      <td className="px-8 py-5 text-right">
                         <button className="p-2 text-cyan-600 hover:bg-cyan-100 rounded-lg"><i className="fa-solid fa-file-contract"></i></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
             </table>
          </div>
        </div>
      )}

      {/* HIRING FORMS MODALS */}
      {activeForm && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-4xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 max-h-[90vh] flex flex-col">
            <div className="p-8 border-b flex justify-between items-center bg-slate-50/50">
               <div className="flex items-center gap-5">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl text-white shadow-lg ${
                    activeForm === 'teacher' ? 'bg-blue-600' : activeForm === 'secretary' ? 'bg-indigo-600' : 'bg-blue-500'
                  }`}>
                    <i className={`fa-solid ${activeForm === 'teacher' ? 'fa-chalkboard-user' : activeForm === 'secretary' ? 'fa-file-signature' : 'fa-ranking-star'}`}></i>
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-slate-800 tracking-tight">
                      {activeForm === 'teacher' ? 'Contratação de Professor' : activeForm === 'secretary' ? 'Contratação de Secretaria' : 'Avaliação Docente'}
                    </h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Preencha os campos essenciais para o registo</p>
                  </div>
               </div>
               <button onClick={closeForm} className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-800"><i className="fa-solid fa-xmark"></i></button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
               <form onSubmit={(e) => { e.preventDefault(); closeForm(); }} className="space-y-12">
                  {activeForm === 'teacher' && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                       <h4 className="md:col-span-3 text-[11px] font-black uppercase text-blue-600 border-b pb-2 tracking-widest">Identificação & Dados Pessoais (25 Campos)</h4>
                       {/* Simplified list for brevity in implementation, following user request for "25 essenciais" */}
                       <input placeholder="Nome Completo" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" required />
                       <input type="date" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" required />
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Gênero: Masculino</option><option>Gênero: Feminino</option></select>
                       <input placeholder="Nacionalidade" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Nº de BI / Passaporte" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" required />
                       <input placeholder="NIF (Contribuinte)" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input type="email" placeholder="Email Institucional" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Telefone Principal" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Endereço Residencial" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Bairro" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Cidade / Província" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       
                       <h4 className="md:col-span-3 text-[11px] font-black uppercase text-blue-600 border-b pb-2 tracking-widest">Formação & Experiência</h4>
                       <input placeholder="Grau Académico" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Instituição de Ensino" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Ano de Conclusão" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Disciplina Principal" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Disciplina Secundária" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Anos de Experiência" type="number" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Última Escola Onde Trabalhou" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />

                       <h4 className="md:col-span-3 text-[11px] font-black uppercase text-blue-600 border-b pb-2 tracking-widest">Dados Bancários & Admin</h4>
                       <input placeholder="IBAN (AO06...)" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold md:col-span-2" />
                       <input placeholder="Nome do Banco" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Nº Segurança Social" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Registo Criminal: Limpo</option><option>Registo Criminal: Pendente</option></select>
                       <input placeholder="Línguas Que Domina" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Turno: Manhã</option><option>Turno: Tarde</option><option>Turno: Noite</option></select>
                       <input placeholder="Contacto de Referência" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                    </div>
                  )}

                  {activeForm === 'secretary' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <h4 className="md:col-span-2 text-[11px] font-black uppercase text-indigo-600 border-b pb-2 tracking-widest">Contratação Administrativa (20 Campos)</h4>
                       <input placeholder="Nome Completo" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" required />
                       <input type="date" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" required />
                       <input placeholder="Nº de BI" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" required />
                       <input placeholder="NIF" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input type="email" placeholder="Email" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Telefone" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Bairro / Residência" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Cidade" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Habilitações: Médio Concluído</option><option>Habilitações: Licenciatura</option></select>
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Domínio Informática: Avançado</option><option>Domínio Informática: Médio</option></select>
                       <input placeholder="Velocidade de Digitação (ppm)" type="number" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Experiência em Secretariado (Anos)" type="number" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Último Empregador" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="IBAN" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Banco" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Nº Seg. Social" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <input placeholder="Língua Estrangeira (Ing/Fr)" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold" />
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Disponibilidade: Imediata</option><option>Disponibilidade: 30 Dias</option></select>
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold"><option>Turno Preferencial: Manhã</option><option>Turno Preferencial: Tarde</option></select>
                       <input placeholder="Observações Adicionais" className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold md:col-span-2" />
                    </div>
                  )}

                  {activeForm === 'eval' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <h4 className="md:col-span-2 text-[11px] font-black uppercase text-blue-600 border-b pb-2 tracking-widest">Parâmetros de Avaliação Docente (20 Parâmetros)</h4>
                       <select className="w-full p-4 bg-slate-50 border rounded-2xl text-sm font-bold md:col-span-2"><option>Seleccionar Professor para Avaliação...</option></select>
                       {[
                         "Planificação de Aulas", "Domínio da Disciplina", "Punctualidade", "Engajamento dos Alunos",
                         "Uso de Tecnologias Educativas", "Gestão de Comportamento", "Rapidez no Lançamento Notas",
                         "Relacionamento com Colegas", "Relacionamento com Encarregados", "Participação em Actividades",
                         "Apresentação / Postura", "Assiduidade Mensal", "Qualidade das Justificativas",
                         "Inovação Pedagógica", "Qualidade do Feedback", "Cumprimento das Normas",
                         "Participação em Reuniões", "Inteligência Emocional", "Formação Contínua (Cursos)",
                         "Pontuação Global de Desempenho"
                       ].map((param, i) => (
                         <div key={i} className="flex flex-col gap-2">
                            <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest ml-1">{param}</label>
                            <input type="range" min="0" max="100" className="w-full accent-blue-600" />
                         </div>
                       ))}
                    </div>
                  )}

                  <div className="flex gap-4 pt-10">
                     <button type="button" onClick={closeForm} className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-2xl font-black uppercase text-xs tracking-widest">Cancelar</button>
                     <button type="submit" className="flex-[2] py-5 bg-slate-900 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-2xl">Gravar Informações</button>
                  </div>
               </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DirectionView;
