
import React from 'react';
import { Student, Payment } from '../types';
import { MOCK_PAYMENTS } from '../constants';

interface FinanceViewProps {
  students: Student[];
}

const FinanceView: React.FC<FinanceViewProps> = ({ students }) => {
  const totalRevenue = MOCK_PAYMENTS.reduce((acc, curr) => acc + curr.amount, 0);
  const pendingCount = students.filter(s => s.paymentStatus === 'Pending' || s.paymentStatus === 'Overdue').length;

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Receita Mensal</p>
          <h3 className="text-2xl font-bold text-slate-800">{totalRevenue.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</h3>
          <p className="text-xs text-emerald-600 mt-2 font-bold"><i className="fa-solid fa-arrow-up mr-1"></i> +12% vs mês anterior</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Pendentes</p>
          <h3 className="text-2xl font-bold text-amber-600">{pendingCount} Alunos</h3>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
            <div className="bg-amber-500 h-full w-1/3"></div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-1">Taxa de Cobrança</p>
          <h3 className="text-2xl font-bold text-blue-600">84%</h3>
          <p className="text-xs text-slate-400 mt-2">Meta Institucional: 95%</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/30">
          <h3 className="font-bold text-slate-800">Histórico de Transações</h3>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 bg-white border rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors">Exportar PDF</button>
            <button className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors">Novo Pagamento</button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-400 text-[10px] uppercase font-bold">
              <tr>
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Estudante</th>
                <th className="px-6 py-4">Tipo</th>
                <th className="px-6 py-4 text-right">Valor</th>
                <th className="px-6 py-4 text-center">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {MOCK_PAYMENTS.map(p => (
                <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-xs font-medium text-slate-500">{p.date}</td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-800">{p.studentName}</td>
                  <td className="px-6 py-4">
                    <span className="text-[10px] px-2 py-0.5 bg-slate-100 rounded text-slate-500 font-bold uppercase">{p.type}</span>
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-bold text-slate-800">
                    {p.amount.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      p.status === 'Completed' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                    }`}>
                      {p.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FinanceView;
