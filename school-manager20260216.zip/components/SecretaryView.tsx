
import React, { useState } from 'react';
import { Student } from '../types';
import { CLASSES_LIST } from '../constants';

interface SecretaryViewProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  schoolId: string;
}

const TURMAS_LIST = Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i));

const SecretaryView: React.FC<SecretaryViewProps> = ({ students, setStudents, schoolId }) => {
  const [showForm, setShowForm] = useState(false);
  const [newStudent, setNewStudent] = useState({
    name: '',
    email: '',
    grade: '1ª Classe',
    gender: 'M' as 'M' | 'F',
    birthDate: '',
    // Family
    fatherName: '',
    motherName: '',
    emergencyContact: '',
    emergencyPhone: '',
    // Medical
    bloodType: '',
    allergies: '',
    conditions: '',
    // Location
    address: '',
    neighborhood: '',
    city: 'Luanda'
  });

  const calculateAge = (birthday: string) => {
    if (!birthday) return 0;
    const ageDifMs = Date.now() - new Date(birthday).getTime();
    const ageDate = new Date(ageDifMs);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  };

  const handleEnroll = (e: React.FormEvent) => {
    e.preventDefault();
    
    const age = calculateAge(newStudent.birthDate);
    const shift = age <= 13 ? 'Manhã' : 'Tarde';
    
    const matchingStudents = students.filter(s => 
      s.schoolId === schoolId && 
      s.grade.split(' - ')[0] === newStudent.grade && 
      s.shift === shift
    );
    
    const totalMatching = matchingStudents.length;
    const turmaIndex = Math.floor(totalMatching / 45);
    const turmaLetter = TURMAS_LIST[turmaIndex] || 'Z';
    const roomNumber = (turmaIndex + 1).toString();
    
    const fullGradeLabel = `${newStudent.grade} - Turma ${turmaLetter}`;

    const student: Student = {
      id: Date.now().toString(),
      name: newStudent.name,
      email: newStudent.email,
      grade: fullGradeLabel,
      status: 'Active',
      gpa: 0,
      lastAttendance: new Date().toISOString().split('T')[0],
      avatar: `https://picsum.photos/seed/${newStudent.name}/150`,
      paymentStatus: 'Pending',
      enrollmentDate: new Date().toISOString().split('T')[0],
      gender: newStudent.gender,
      schoolId: schoolId,
      birthDate: newStudent.birthDate,
      shift: shift,
      room: roomNumber,
      turma: turmaLetter,
      familyInfo: {
        fatherName: newStudent.fatherName,
        motherName: newStudent.motherName,
        emergencyContact: newStudent.emergencyContact,
        emergencyPhone: newStudent.emergencyPhone,
      },
      medicalInfo: {
        bloodType: newStudent.bloodType,
        allergies: newStudent.allergies,
        conditions: newStudent.conditions,
      },
      locationInfo: {
        address: newStudent.address,
        neighborhood: newStudent.neighborhood,
        city: newStudent.city,
      }
    };

    setStudents(prev => [student, ...prev]);
    
    // Reset form
    setNewStudent({
      name: '', email: '', grade: '1ª Classe', gender: 'M', birthDate: '',
      fatherName: '', motherName: '', emergencyContact: '', emergencyPhone: '',
      bloodType: '', allergies: '', conditions: '',
      address: '', neighborhood: '', city: 'Luanda'
    });
    setShowForm(false);
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Serviços de Secretaria</h2>
          <p className="text-slate-500 text-sm">Controle de matrículas e alocação automática de turmas.</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-blue-600/20 active:scale-95"
        >
          <i className={`fa-solid ${showForm ? 'fa-xmark' : 'fa-user-plus'}`}></i>
          {showForm ? 'Cancelar' : 'Nova Matrícula'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-8 rounded-[40px] border border-blue-100 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-500 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-8 opacity-[0.03]">
             <i className="fa-solid fa-file-signature text-[120px]"></i>
          </div>

          <div className="flex items-center gap-4 mb-10">
            <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-2xl shadow-lg shadow-blue-500/20">
              <i className="fa-solid fa-id-card"></i>
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-800 tracking-tight">Nova Inscrição Académica</h3>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Preencha todos os campos obrigatórios para o registo.</p>
            </div>
          </div>

          <form onSubmit={handleEnroll} className="space-y-12">
            {/* Secção 1: Dados Académicos e Pessoais */}
            <section className="space-y-6">
              <h4 className="text-[10px] font-black uppercase text-blue-600 tracking-[0.3em] flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600"></div>
                1. Dados Pessoais & Académicos
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome Completo do Aluno</label>
                  <input 
                    type="text" placeholder="Ex: Machado Armando" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                    value={newStudent.name}
                    onChange={e => setNewStudent({...newStudent, name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Data de Nascimento</label>
                  <input 
                    type="date" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                    value={newStudent.birthDate}
                    onChange={e => setNewStudent({...newStudent, birthDate: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Género</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                    value={newStudent.gender}
                    onChange={e => setNewStudent({...newStudent, gender: e.target.value as 'M' | 'F'})}
                  >
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                  </select>
                </div>
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Classe pretendida</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                    value={newStudent.grade}
                    onChange={e => setNewStudent({...newStudent, grade: e.target.value})}
                  >
                    {CLASSES_LIST.map(cls => <option key={cls} value={cls}>{cls}</option>)}
                  </select>
                </div>
              </div>
            </section>

            {/* Secção 2: Dados Familiares */}
            <section className="space-y-6">
              <h4 className="text-[10px] font-black uppercase text-indigo-600 tracking-[0.3em] flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-600"></div>
                2. Dados Familiares & Contactos
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome do Pai</label>
                  <input 
                    type="text" placeholder="Nome Completo do Pai" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    value={newStudent.fatherName}
                    onChange={e => setNewStudent({...newStudent, fatherName: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome da Mãe</label>
                  <input 
                    type="text" placeholder="Nome Completo da Mãe" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    value={newStudent.motherName}
                    onChange={e => setNewStudent({...newStudent, motherName: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Contacto de Emergência (Nome)</label>
                  <input 
                    type="text" placeholder="Ex: Nome do Encarregado de Educação" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    value={newStudent.emergencyContact}
                    onChange={e => setNewStudent({...newStudent, emergencyContact: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Telefone Emergência</label>
                  <input 
                    type="tel" placeholder="9XXXXXXXX" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    value={newStudent.emergencyPhone}
                    onChange={e => setNewStudent({...newStudent, emergencyPhone: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Encarregado</label>
                  <input 
                    type="email" placeholder="email@exemplo.com" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    value={newStudent.email}
                    onChange={e => setNewStudent({...newStudent, email: e.target.value})}
                    required
                  />
                </div>
              </div>
            </section>

            {/* Secção 3: Dados Médicos */}
            <section className="space-y-6">
              <h4 className="text-[10px] font-black uppercase text-rose-600 tracking-[0.3em] flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-rose-600"></div>
                3. Informações de Saúde
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Tipo Sanguíneo</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-rose-500/10 transition-all"
                    value={newStudent.bloodType}
                    onChange={e => setNewStudent({...newStudent, bloodType: e.target.value})}
                  >
                    <option value="">Não Informado</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>
                <div className="md:col-span-3 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Alergias / Condições Médicas</label>
                  <input 
                    type="text" placeholder="Ex: Alergia a amendoim, Asma, Diabetes..." 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-rose-500/10 transition-all"
                    value={newStudent.allergies}
                    onChange={e => setNewStudent({...newStudent, allergies: e.target.value})}
                  />
                </div>
              </div>
            </section>

            {/* Secção 4: Localização */}
            <section className="space-y-6">
              <h4 className="text-[10px] font-black uppercase text-amber-600 tracking-[0.3em] flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-600"></div>
                4. Endereço e Localização
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Endereço Residencial</label>
                  <input 
                    type="text" placeholder="Rua, Número da Casa..." 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-amber-500/10 transition-all"
                    value={newStudent.address}
                    onChange={e => setNewStudent({...newStudent, address: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Bairro</label>
                  <input 
                    type="text" placeholder="Ex: Bairro Talatona" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-amber-500/10 transition-all"
                    value={newStudent.neighborhood}
                    onChange={e => setNewStudent({...newStudent, neighborhood: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Província / Cidade</label>
                  <input 
                    type="text" placeholder="Ex: Luanda" 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 focus:ring-amber-500/10 transition-all"
                    value={newStudent.city}
                    onChange={e => setNewStudent({...newStudent, city: e.target.value})}
                    required
                  />
                </div>
              </div>
            </section>

            <div className="flex justify-end gap-4 pt-8 border-t border-slate-100">
              <button 
                type="button" 
                onClick={() => setShowForm(false)} 
                className="px-8 py-4 text-slate-400 text-xs font-black uppercase tracking-widest hover:text-slate-600 hover:bg-slate-50 rounded-2xl transition-all"
              >
                Descartar Formulário
              </button>
              <button 
                type="submit" 
                className="px-12 py-5 bg-slate-900 text-white rounded-[24px] text-xs font-black uppercase tracking-widest shadow-2xl shadow-slate-900/20 hover:bg-slate-800 transition-all active:scale-95 flex items-center gap-3"
              >
                Concluir Matrícula <i className="fa-solid fa-check-double"></i>
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-[40px] shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-8 border-b bg-slate-50/50 flex items-center justify-between">
          <div>
            <h3 className="font-black text-slate-800 uppercase tracking-widest text-xs mb-1">Registos de Alunos da Unidade</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Visualização rápida de matrículas efetuadas</p>
          </div>
          <span className="text-[10px] font-black text-blue-600 bg-blue-100 px-4 py-1.5 rounded-full uppercase tracking-widest border border-blue-200">{students.length} Total</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-400 text-[10px] uppercase font-black tracking-[0.2em]">
              <tr>
                <th className="px-8 py-5">Estudante</th>
                <th className="px-6 py-5">Classe & Turma</th>
                <th className="px-6 py-5">Turno / Sala</th>
                <th className="px-6 py-5">Estado</th>
                <th className="px-8 py-5 text-right">Acções</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {students.map(s => (
                <tr key={s.id} className="hover:bg-blue-50/30 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-slate-100 overflow-hidden shadow-sm group-hover:scale-105 transition-transform border-2 border-white">
                         <img src={s.avatar} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="text-sm font-black text-slate-800 group-hover:text-blue-600 transition-colors">{s.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{calculateAge(s.birthDate)} anos • {s.gender === 'M' ? 'Masc.' : 'Fem.'}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className="px-3 py-1.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-sm">
                      {s.grade}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-2">
                       <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${s.shift === 'Manhã' ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'}`}>
                         {s.shift || 'N/A'}
                       </span>
                       <span className="px-2 py-1 bg-slate-100 rounded-lg text-[9px] font-black text-slate-500 uppercase tracking-widest">
                         Sala {s.room || '-'}
                       </span>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${
                      s.paymentStatus === 'Paid' ? 'bg-emerald-100 text-emerald-700' : 
                      s.paymentStatus === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                    }`}>
                      {s.paymentStatus === 'Paid' ? 'Regular' : s.paymentStatus === 'Pending' ? 'Pendente' : 'Irregular'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right space-x-2">
                    <button className="text-blue-600 hover:bg-blue-600 hover:text-white p-2.5 rounded-xl transition-all border border-blue-50 shadow-sm" title="Imprimir Ficha"><i className="fa-solid fa-file-pdf"></i></button>
                    <button className="text-slate-400 hover:bg-slate-900 hover:text-white p-2.5 rounded-xl transition-all border border-slate-50 shadow-sm" title="Visualizar Detalhes"><i className="fa-solid fa-eye"></i></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {students.length === 0 && (
            <div className="p-20 text-center">
               <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                  <i className="fa-solid fa-folder-open text-2xl"></i>
               </div>
               <p className="text-slate-400 text-sm font-medium italic">Nenhum aluno matriculado nesta unidade académica.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SecretaryView;
