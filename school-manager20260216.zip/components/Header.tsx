
import React, { useState } from 'react';
import { Locale, LANGUAGES, translations } from '../i18n';

interface HeaderProps {
  title: string;
  openSidebar: () => void;
  locale: Locale;
  setLocale: (locale: Locale) => void;
  onLoginClick: () => void;
  onRegisterClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  title, 
  openSidebar, 
  locale, 
  setLocale, 
  onLoginClick, 
  onRegisterClick 
}) => {
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isAccessOpen, setIsAccessOpen] = useState(false);
  const t = translations[locale];

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 sticky top-0 z-30">
      <div className="flex items-center gap-4">
        <button 
          onClick={openSidebar}
          className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <i className="fa-solid fa-bars text-xl"></i>
        </button>
        <h2 className="text-xl font-bold capitalize text-slate-800 tracking-tight">
          {t[title.toLowerCase()] || title}
        </h2>
      </div>

      <div className="flex items-center gap-3 lg:gap-4">
        <div className="hidden md:flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all">
          <i className="fa-solid fa-magnifying-glass text-slate-400 text-sm"></i>
          <input 
            type="text" 
            placeholder={t.search} 
            className="bg-transparent border-none focus:ring-0 text-sm w-48 lg:w-64"
          />
        </div>

        {/* Language Selector */}
        <div className="relative">
          <button 
            onClick={() => setIsLangOpen(!isLangOpen)}
            className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-2 border border-transparent hover:border-slate-200"
          >
            <i className="fa-solid fa-globe text-lg"></i>
            <span className="hidden sm:inline text-[10px] font-black uppercase tracking-tighter">{locale}</span>
          </button>

          {isLangOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsLangOpen(false)}></div>
              <div className="absolute top-full mt-2 right-0 w-72 bg-white rounded-2xl shadow-2xl border border-slate-100 p-3 z-50 animate-in fade-in zoom-in-95 duration-200">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 px-2">Alterar Idioma</p>
                <div className="grid grid-cols-2 gap-1">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLocale(lang.code);
                        setIsLangOpen(false);
                      }}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${
                        locale === lang.code 
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                          : 'hover:bg-slate-50 text-slate-600'
                      }`}
                    >
                      <span className="text-lg">{lang.flag}</span>
                      <span className="text-xs font-bold">{lang.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        <button className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
          <i className="fa-solid fa-bell"></i>
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
        </button>

        {/* Optimized Unified Access Button */}
        <div className="relative">
          <button 
            onClick={() => setIsAccessOpen(!isAccessOpen)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all shadow-xl active:scale-95 ${
              isAccessOpen 
              ? 'bg-blue-600 text-white shadow-blue-600/20' 
              : 'bg-slate-900 text-white shadow-slate-900/10 hover:bg-slate-800'
            }`}
          >
            <i className={`fa-solid ${isAccessOpen ? 'fa-user-lock' : 'fa-circle-user'} text-sm ${isAccessOpen ? 'text-white' : 'text-blue-400'}`}></i>
            <span className="hidden sm:inline">Portal de Acesso</span>
            <i className={`fa-solid fa-chevron-down text-[10px] transition-transform duration-300 ${isAccessOpen ? 'rotate-180' : ''}`}></i>
          </button>

          {isAccessOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsAccessOpen(false)}></div>
              <div className="absolute top-full mt-3 right-0 w-64 bg-white rounded-[32px] shadow-2xl border border-slate-100 p-3 z-50 animate-in fade-in slide-in-from-top-4 duration-300">
                <div className="px-4 py-3 mb-2 border-b border-slate-50">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Acesso Académico</p>
                </div>
                
                <button 
                  onClick={() => { setIsAccessOpen(false); onLoginClick(); }}
                  className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-slate-700 hover:bg-blue-50 transition-all text-left group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                    <i className="fa-solid fa-right-to-bracket text-lg"></i>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-black text-slate-800 group-hover:text-blue-700 transition-colors">Iniciar Sessão</span>
                    <span className="text-[10px] text-slate-400 font-medium leading-tight">Aceda ao seu painel de controlo administrativo</span>
                  </div>
                </button>

                <button 
                  onClick={() => { setIsAccessOpen(false); onRegisterClick(); }}
                  className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-slate-700 hover:bg-emerald-50 transition-all text-left group mt-1"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-sm">
                    <i className="fa-solid fa-user-plus text-lg"></i>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-black text-slate-800 group-hover:text-emerald-700 transition-colors">Criar Conta</span>
                    <span className="text-[10px] text-slate-400 font-medium leading-tight">Registe novos colaboradores ou encarregados</span>
                  </div>
                </button>

                <div className="mt-3 pt-3 border-t border-slate-50 px-2">
                   <p className="text-[8px] text-slate-300 text-center font-bold uppercase tracking-widest">SM@ School Management System v1.0</p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
