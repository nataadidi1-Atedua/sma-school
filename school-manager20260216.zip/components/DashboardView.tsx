
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Student, Teacher, CurriculumSuggestion } from '../types';
import { PERFORMANCE_DATA } from '../constants';
import { Locale, translations } from '../i18n';
import { getCurriculumSuggestions } from '../services/geminiService';

interface DashboardViewProps {
  students: Student[];
  teachers: Teacher[];
  locale: Locale;
  schoolName: string;
}

const DashboardView: React.FC<DashboardViewProps> = ({ students, teachers, locale, schoolName }) => {
  const t = translations[locale];
  const activeStudents = students.filter(s => s.status === 'Active').length;
  const avgGpa = (students.reduce((acc, s) => acc + s.gpa, 0) / (students.length || 1)).toFixed(2);
  
  const [suggestions, setSuggestions] = useState<CurriculumSuggestion[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (students.length > 0) {
        setLoadingSuggestions(true);
        const results = await getCurriculumSuggestions(students);
        setSuggestions(results);
        setLoadingSuggestions(false);
      }
    };
    fetchSuggestions();
  }, [students]);

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tight">{schoolName}</h2>
          <p className="text-slate-500 font-medium">{t.dashboard}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: t.totalStudents, value: students.length, color: 'blue', icon: 'fa-user-graduate' },
          { label: t.teachers, value: teachers.length, color: 'purple', icon: 'fa-chalkboard-user' },
          { label: t.avgGpa, value: avgGpa, color: 'emerald', icon: 'fa-star' },
          { label: t.active, value: activeStudents, color: 'amber', icon: 'fa-circle-check' },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between group hover:shadow-md transition-shadow">
            <div>
              <p className="text-sm font-medium text-slate-500 mb-1">{stat.label}</p>
              <h3 className="text-2xl font-bold text-slate-800">{stat.value}</h3>
            </div>
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-${stat.color}-50 text-${stat.color}-600 group-hover:scale-110 transition-transform`}>
              <i className={`fa-solid ${stat.icon} text-xl`}></i>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Performance Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800">Desempenho por Disciplina</h3>
            <button className="text-sm text-slate-400 hover:text-slate-600">
              <i className="fa-solid fa-ellipsis-vertical"></i>
            </button>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={PERFORMANCE_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis hide />
                <Tooltip 
                   cursor={{fill: '#f8fafc'}}
                   contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                />
                <Bar dataKey="avg" fill="#2563eb" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Curriculum Suggestions */}
        <div className="bg-slate-900 rounded-3xl shadow-xl p-6 text-white border border-slate-800 overflow-hidden relative">
           <div className="absolute top-0 right-0 p-4 opacity-5">
             <i className="fa-solid fa-brain text-8xl"></i>
           </div>
           <h3 className="font-black text-xs uppercase tracking-widest text-blue-400 mb-6 flex items-center gap-2">
             <i className="fa-solid fa-wand-magic-sparkles"></i>
             Ajustes Curriculares AI
           </h3>
           
           <div className="space-y-4 max-h-[350px] overflow-y-auto custom-scrollbar pr-2">
             {loadingSuggestions ? (
               <div className="flex flex-col items-center justify-center py-10 gap-3">
                  <i className="fa-solid fa-spinner animate-spin text-3xl text-blue-500"></i>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter">Analisando Performance...</p>
               </div>
             ) : suggestions.length > 0 ? (
               suggestions.map((s, i) => (
                 <div key={i} className="p-4 bg-slate-800 rounded-2xl border border-slate-700 hover:border-blue-500/50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-[10px] font-black uppercase text-blue-400 bg-blue-400/10 px-2 py-0.5 rounded">{s.subject}</span>
                    </div>
                    <p className="text-sm font-bold text-slate-100 mb-1">{s.topic}</p>
                    <p className="text-[10px] text-slate-400 leading-relaxed italic mb-3">"{s.reason}"</p>
                    <div className="space-y-1">
                       <p className="text-[8px] font-black uppercase text-slate-500">Materiais Sugeridos:</p>
                       <div className="flex flex-wrap gap-1">
                          {s.suggestedMaterials.map((m, mi) => (
                            <span key={mi} className="text-[9px] bg-slate-700 px-2 py-1 rounded text-slate-300">{m}</span>
                          ))}
                       </div>
                    </div>
                 </div>
               ))
             ) : (
               <p className="text-xs text-slate-500 italic text-center py-10">Dados insuficientes para sugestões.</p>
             )}
           </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
