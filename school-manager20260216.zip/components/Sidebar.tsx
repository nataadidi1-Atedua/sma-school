
import React, { useState } from 'react';
import { ViewType, School } from '../types';
import { Locale, translations } from '../i18n';

interface SidebarProps {
  currentView: ViewType;
  setView: (view: ViewType) => void;
  isOpen: boolean;
  closeSidebar: () => void;
  locale: Locale;
  schools: School[];
  currentSchool: School;
  setCurrentSchool: (school: School) => void;
  userAvatar: string;
  onProfileClick: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  currentView, setView, isOpen, locale, 
  schools, currentSchool, setCurrentSchool, userAvatar, onProfileClick 
}) => {
  const t = translations[locale];
  const [isSchoolListOpen, setIsSchoolListOpen] = useState(false);

  const navItems = [
    { type: ViewType.DASHBOARD, icon: 'fa-gauge-high', label: t.dashboard },
    { type: ViewType.DIRECTION, icon: 'fa-building-columns', label: t.direction },
    { type: ViewType.SECRETARY, icon: 'fa-file-signature', label: t.secretary },
    { type: ViewType.FINANCE, icon: 'fa-money-bill-transfer', label: t.finance },
    { type: ViewType.CLASSES_DETAILED, icon: 'fa-users-rectangle', label: t.classes },
    { type: ViewType.STUDENTS, icon: 'fa-user-graduate', label: t.students },
    { type: ViewType.TEACHERS, icon: 'fa-chalkboard-user', label: t.teachers },
    { type: ViewType.AI_INSIGHTS, icon: 'fa-brain', label: t.ai },
    { type: ViewType.SETTINGS, icon: 'fa-sliders', label: t.settings },
  ];

  return (
    <aside className={`
      fixed inset-y-0 ${locale === 'ar' ? 'right-0' : 'left-0'} z-50 w-72 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0
      ${isOpen ? 'translate-x-0' : (locale === 'ar' ? 'translate-x-full' : '-translate-x-full')}
    `}>
      <div className="p-6 flex flex-col h-full">
        {/* School Switcher */}
        <div className="relative mb-8">
           <button 
             onClick={() => setIsSchoolListOpen(!isSchoolListOpen)}
             className="w-full flex items-center gap-3 p-3 bg-slate-800 rounded-2xl hover:bg-slate-700 transition-all border border-slate-700 group"
           >
             <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center font-bold text-lg shrink-0 group-hover:scale-105 transition-transform">
               {currentSchool.name.charAt(0)}
             </div>
             <div className="text-left overflow-hidden">
               <h1 className="font-bold text-sm leading-tight truncate">{currentSchool.name}</h1>
               <p className="text-[10px] text-slate-400 truncate">{currentSchool.location}</p>
             </div>
             <i className={`fa-solid fa-chevron-down text-[10px] ml-auto transition-transform ${isSchoolListOpen ? 'rotate-180' : ''}`}></i>
           </button>

           {isSchoolListOpen && (
             <>
               <div className="fixed inset-0 z-40" onClick={() => setIsSchoolListOpen(false)}></div>
               <div className="absolute top-full left-0 right-0 mt-2 bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl z-50 py-2 max-h-80 overflow-y-auto custom-scrollbar animate-in fade-in slide-in-from-top-2">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4 py-2">Mudar Unidade</p>
                 {schools.map(school => (
                   <button 
                     key={school.id}
                     onClick={() => {
                       setCurrentSchool(school);
                       setIsSchoolListOpen(false);
                     }}
                     className={`w-full flex items-center gap-3 px-4 py-2 hover:bg-slate-700 transition-colors text-left ${currentSchool.id === school.id ? 'bg-blue-600/10' : ''}`}
                   >
                     <div className={`w-6 h-6 rounded bg-slate-700 flex items-center justify-center text-[10px] font-bold ${currentSchool.id === school.id ? 'bg-blue-600' : ''}`}>
                       {school.name.charAt(0)}
                     </div>
                     <span className={`text-xs font-bold truncate ${currentSchool.id === school.id ? 'text-blue-400' : 'text-slate-300'}`}>{school.name}</span>
                   </button>
                 ))}
               </div>
             </>
           )}
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto custom-scrollbar pr-2">
          {navItems.map((item) => (
            <button
              key={item.type}
              onClick={() => setView(item.type)}
              className={`
                w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200
                ${currentView === item.type 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
              `}
            >
              <i className={`fa-solid ${item.icon} w-5 text-sm`}></i>
              <span className="font-medium text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-800">
          <button 
            onClick={onProfileClick}
            className="w-full flex items-center gap-3 px-4 py-3 bg-slate-800 rounded-2xl mb-4 hover:bg-slate-700 transition-all border border-transparent hover:border-blue-500/30 group"
          >
            <div className="relative">
              <img src={userAvatar} alt="Admin" className="w-10 h-10 rounded-full border-2 border-blue-500 object-cover" />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center text-[8px] border-2 border-slate-800">
                <i className="fa-solid fa-camera"></i>
              </div>
            </div>
            <div className="overflow-hidden text-left">
              <p className="text-xs font-semibold truncate">Admin Principal</p>
              <p className="text-[10px] text-slate-400">Gabinete Central</p>
            </div>
          </button>
          <button className="w-full text-left text-xs text-slate-400 hover:text-white px-4">
            <i className={`fa-solid fa-right-from-bracket ${locale === 'ar' ? 'rotate-180 ml-2' : 'mr-2'}`}></i> {t.logout}
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
