
import React, { useState, useRef, useMemo } from 'react';
import { Student } from '../types';
import { CLASSES_LIST } from '../constants';

interface StudentManagementProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}

const StudentManagement: React.FC<StudentManagementProps> = ({ students, setStudents }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Inactive'>('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => {
    return students.filter(s => {
      const matchesSearch = 
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        s.grade.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'All' || s.status === statusFilter;
      
      const matchesStartDate = !startDate || s.enrollmentDate >= startDate;
      const matchesEndDate = !endDate || s.enrollmentDate <= endDate;
      
      return matchesSearch && matchesStatus && matchesStartDate && matchesEndDate;
    });
  }, [students, searchTerm, statusFilter, startDate, endDate]);

  const handleDelete = () => {
    if (studentToDelete) {
      setStudents(prev => prev.filter(s => s.id !== studentToDelete));
      setStudentToDelete(null);
    }
  };

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingStudent) {
      setStudents(prev => prev.map(s => s.id === editingStudent.id ? editingStudent : s));
      setEditingStudent(null);
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingStudent) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingStudent({
          ...editingStudent,
          avatar: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('All');
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Directório de Alunos</h2>
          <p className="text-slate-500 text-sm">Gerencie todos os registros académicos e pessoais dos estudantes.</p>
        </div>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-blue-600/20 active:scale-95">
          <i className="fa-solid fa-plus"></i>
          Registar Aluno
        </button>
      </div>

      <div className="bg-white rounded-[32px] shadow-sm border border-slate-100 overflow-hidden">
        {/* Search and Filters Bar */}
        <div className="p-6 bg-slate-50/50 border-b border-slate-100 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input 
                type="text" 
                placeholder="Pesquisar por nome ou classe..." 
                className="w-full pl-12 pr-4 py-3 rounded-2xl border border-slate-200 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-400 outline-none text-sm font-medium transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-xs transition-all border ${
                  showFilters || statusFilter !== 'All' || startDate || endDate
                    ? 'bg-blue-50 border-blue-200 text-blue-600' 
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <i className="fa-solid fa-filter"></i>
                Filtros Avançados
                {(statusFilter !== 'All' || startDate || endDate) && (
                  <span className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>
                )}
              </button>
              {(searchTerm || statusFilter !== 'All' || startDate || endDate) && (
                <button 
                  onClick={clearFilters}
                  className="px-5 py-3 rounded-2xl font-bold text-xs text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all"
                >
                  Limpar
                </button>
              )}
            </div>
          </div>

          {/* Expanded Filters Panel */}
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-slate-200/50 animate-in slide-in-from-top-2 duration-300">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Status do Aluno</label>
                <div className="flex bg-white p-1 rounded-xl border border-slate-200">
                  {(['All', 'Active', 'Inactive'] as const).map((status) => (
                    <button
                      key={status}
                      onClick={() => setStatusFilter(status)}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                        statusFilter === status 
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                          : 'text-slate-500 hover:bg-slate-50'
                      }`}
                    >
                      {status === 'All' ? 'Todos' : status === 'Active' ? 'Ativo' : 'Inativo'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Matrícula (Desde)</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Matrícula (Até)</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-400 uppercase text-[10px] font-black tracking-widest">
              <tr>
                <th className="px-8 py-5">Estudante</th>
                <th className="px-6 py-5">Classe / Turma</th>
                <th className="px-6 py-5">Estado Financeiro</th>
                <th className="px-6 py-5 text-center">Rendimento (GPA)</th>
                <th className="px-6 py-5">Status</th>
                <th className="px-8 py-5 text-right">Acções</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((student) => (
                <tr key={student.id} className="hover:bg-blue-50/30 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-slate-100 overflow-hidden shadow-sm group-hover:scale-105 transition-transform border-2 border-white">
                        <img src={student.avatar} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="font-black text-slate-800 group-hover:text-blue-600 transition-colors">{student.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{student.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className="px-3 py-1.5 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-sm">
                      {student.grade}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 w-fit ${
                      student.paymentStatus === 'Paid' 
                        ? 'bg-emerald-100 text-emerald-700' 
                        : student.paymentStatus === 'Pending'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-rose-100 text-rose-700'
                    }`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${
                        student.paymentStatus === 'Paid' ? 'bg-emerald-600' : student.paymentStatus === 'Pending' ? 'bg-amber-600' : 'bg-rose-600'
                      }`}></div>
                      {student.paymentStatus === 'Paid' ? 'Regular' : student.paymentStatus === 'Pending' ? 'Pendente' : 'Dívida'}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col items-center gap-1.5">
                      <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${student.gpa > 3.5 ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]' : student.gpa > 2.5 ? 'bg-amber-500' : 'bg-red-500'}`} 
                          style={{ width: `${(student.gpa / 4.0) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-xs font-black text-slate-700">{student.gpa.toFixed(1)} <span className="text-[9px] text-slate-400 font-bold uppercase">/ 4.0</span></span>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest ${
                      student.status === 'Active' 
                        ? 'bg-emerald-100 text-emerald-700' 
                        : 'bg-slate-200 text-slate-500'
                    }`}>
                      {student.status === 'Active' ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end gap-2 transition-all">
                      <button 
                        onClick={() => setEditingStudent(student)}
                        className="w-10 h-10 flex items-center justify-center text-blue-600 bg-blue-50 hover:bg-blue-600 hover:text-white rounded-xl transition-all shadow-sm active:scale-95 border border-blue-100"
                        title="Editar Aluno"
                      >
                        <i className="fa-solid fa-pencil text-sm"></i>
                      </button>
                      <button 
                        onClick={() => setStudentToDelete(student.id)}
                        className="w-10 h-10 flex items-center justify-center text-rose-600 bg-rose-50 hover:bg-rose-600 hover:text-white rounded-xl transition-all shadow-sm active:scale-95 border border-rose-100"
                        title="Eliminar Aluno"
                      >
                        <i className="fa-solid fa-trash text-sm"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-20 text-center">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-200">
                      <i className="fa-solid fa-user-slash text-3xl"></i>
                    </div>
                    <p className="text-slate-400 text-sm font-medium italic">Nenhum aluno encontrado para os filtros aplicados.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Modal (Condensed for space) */}
      {editingStudent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-8 border-b bg-slate-50/50 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-2xl shadow-lg">
                  <i className="fa-solid fa-user-pen"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-black text-slate-800 tracking-tight">Editar Perfil</h3>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">ID: {editingStudent.id}</p>
                </div>
              </div>
              <button onClick={() => setEditingStudent(null)} className="w-10 h-10 rounded-xl bg-white border flex items-center justify-center text-slate-400 hover:text-slate-800">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <form onSubmit={handleUpdate} className="p-8 space-y-6">
               {/* Form fields here, updated to include payment status select */}
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Estado de Pagamento</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none"
                    value={editingStudent.paymentStatus}
                    onChange={e => setEditingStudent({...editingStudent, paymentStatus: e.target.value as any})}
                  >
                    <option value="Paid">Regular / Pago</option>
                    <option value="Pending">Pendente</option>
                    <option value="Overdue">Em Dívida</option>
                  </select>
                </div>
                {/* ... existing form fields ... */}
              </div>
              <button type="submit" className="w-full py-4 bg-slate-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-2xl hover:bg-slate-800 transition-all">Guardar Alterações</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentManagement;
