
import React from 'react';
import { Teacher } from '../types';

interface TeacherManagementProps {
  teachers: Teacher[];
  setTeachers: React.Dispatch<React.SetStateAction<Teacher[]>>;
}

const TeacherManagement: React.FC<TeacherManagementProps> = ({ teachers }) => {
  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Faculty</h2>
          <p className="text-slate-500">Overview of active faculty members and teaching assignments.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teachers.map((teacher) => (
          <div key={teacher.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-4">
                <button className="text-slate-300 hover:text-blue-600 transition-colors">
                    <i className="fa-solid fa-ellipsis-vertical"></i>
                </button>
             </div>
             
             <div className="flex flex-col items-center text-center mb-6">
               <img src={teacher.avatar} alt="" className="w-20 h-20 rounded-2xl mb-4 object-cover border-4 border-slate-50" />
               <h3 className="font-bold text-lg text-slate-800">{teacher.name}</h3>
               <p className="text-blue-600 font-medium text-sm">{teacher.subject}</p>
               <p className="text-slate-400 text-xs mt-1">{teacher.email}</p>
             </div>

             <div className="space-y-3">
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Assigned Classes</p>
               <div className="flex flex-wrap gap-2">
                 {teacher.classes.map((cls, i) => (
                   <span key={i} className="px-2.5 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold rounded-lg uppercase">
                     {cls}
                   </span>
                 ))}
               </div>
             </div>

             <div className="mt-6 flex gap-3">
               <button className="flex-1 bg-slate-900 text-white py-2 rounded-xl text-sm font-semibold hover:bg-slate-800 transition-colors">
                 Profile
               </button>
               <button className="w-12 h-10 border border-slate-200 rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-50 transition-colors">
                 <i className="fa-solid fa-message"></i>
               </button>
             </div>
          </div>
        ))}

        <button className="border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center text-slate-400 hover:border-blue-400 hover:text-blue-400 transition-all group">
          <div className="w-12 h-12 rounded-full border-2 border-dashed border-slate-200 flex items-center justify-center mb-3 group-hover:border-blue-400 transition-colors">
            <i className="fa-solid fa-plus text-xl"></i>
          </div>
          <span className="font-semibold">Add Faculty Member</span>
        </button>
      </div>
    </div>
  );
};

export default TeacherManagement;
