
import React, { useState } from 'react';
import { Student, InsightReport } from '../types';
import { getAcademicInsights } from '../services/geminiService';

interface AiInsightsProps {
  students: Student[];
}

const AiInsights: React.FC<AiInsightsProps> = ({ students }) => {
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<InsightReport | null>(null);

  const generateReport = async () => {
    setLoading(true);
    try {
      const result = await getAcademicInsights(students);
      setReport(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-4xl mx-auto">
      <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[40px] text-white shadow-2xl shadow-blue-500/20 relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20">
              <i className="fa-solid fa-brain text-2xl"></i>
            </div>
            <h2 className="text-2xl font-black tracking-tight">Inteligência Acadêmica AI</h2>
          </div>
          <p className="text-blue-100 mb-6 max-w-lg font-medium leading-relaxed">
            Deixe o Gemini analisar o desempenho atual da sua escola para identificar tendências, alunos em risco e oportunidades de crescimento.
          </p>
          <button 
            onClick={generateReport}
            disabled={loading}
            className={`
              bg-white text-blue-600 px-8 py-4 rounded-2xl font-black uppercase text-xs tracking-widest flex items-center gap-3 transition-all shadow-xl
              ${loading ? 'opacity-70 cursor-not-allowed scale-95' : 'hover:shadow-2xl hover:-translate-y-1 active:scale-95'}
            `}
          >
            {loading ? (
              <><i className="fa-solid fa-spinner animate-spin"></i> Analisando Dados...</>
            ) : (
              <><i className="fa-solid fa-wand-magic-sparkles"></i> Gerar Relatório de Insights</>
            )}
          </button>
        </div>
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute right-10 top-10 opacity-10">
          <i className="fa-solid fa-chart-line text-[160px]"></i>
        </div>
      </div>

      {report && (
        <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 space-y-8 pb-12">
          {/* Executive Summary */}
          <div className="bg-white p-10 rounded-[40px] shadow-sm border border-slate-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:scale-110 transition-transform">
               <i className="fa-solid fa-quote-right text-[120px]"></i>
            </div>
            <h3 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em] mb-6 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-600"></div>
              Sumário Executivo
            </h3>
            <p className="text-lg font-medium text-slate-600 leading-relaxed italic pr-12">"{report.summary}"</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Top Performers */}
            <div className="bg-white p-8 rounded-[40px] border border-emerald-50 shadow-sm">
              <h4 className="text-[10px] font-black uppercase text-emerald-600 tracking-[0.3em] mb-8 flex items-center gap-2">
                <i className="fa-solid fa-award text-sm"></i> Destaques Académicos
              </h4>
              <ul className="space-y-3">
                {report.topPerformers.map((name, i) => (
                  <li key={i} className="flex items-center gap-4 text-emerald-800 bg-emerald-50 px-4 py-4 rounded-2xl text-xs font-black shadow-sm border border-emerald-100 group hover:bg-emerald-600 hover:text-white transition-all duration-300">
                    <div className="w-8 h-8 rounded-xl bg-white text-emerald-600 flex items-center justify-center shadow-sm group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                      <i className="fa-solid fa-star"></i>
                    </div>
                    {name}
                  </li>
                ))}
              </ul>
            </div>

            {/* Risk Identified - HIGHLIGHTED ALERT COLOR */}
            <div className="bg-white p-8 rounded-[40px] border border-rose-50 shadow-sm">
              <h4 className="text-[10px] font-black uppercase text-rose-600 tracking-[0.3em] mb-8 flex items-center gap-2">
                <i className="fa-solid fa-triangle-exclamation text-sm animate-pulse"></i> Alunos em Risco Crítico
              </h4>
              <ul className="space-y-4">
                {report.riskStudents.map((name, i) => (
                  <li key={i} className="flex items-center justify-between gap-3 text-rose-800 bg-rose-100/70 border border-rose-200 px-5 py-4 rounded-2xl text-xs font-black group hover:bg-rose-600 hover:text-white hover:border-rose-600 transition-all duration-300 shadow-md shadow-rose-600/5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-white text-rose-600 flex items-center justify-center shadow-sm group-hover:bg-rose-500 group-hover:text-white transition-all">
                        <i className="fa-solid fa-user-xmark"></i>
                      </div>
                      <span className="truncate max-w-[140px]">{name}</span>
                    </div>
                    <span className="text-[9px] font-black uppercase tracking-widest bg-rose-600 text-white px-3 py-1.5 rounded-lg group-hover:bg-white group-hover:text-rose-600 transition-colors shadow-sm">
                      Urgente
                    </span>
                  </li>
                ))}
                {report.riskStudents.length === 0 && (
                   <li className="text-center py-6 text-slate-400 italic text-xs">Nenhum aluno em risco detectado.</li>
                )}
              </ul>
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-slate-900 p-10 rounded-[48px] text-white shadow-2xl relative overflow-hidden">
             <div className="absolute top-0 right-0 p-10 opacity-5">
               <i className="fa-solid fa-lightbulb text-[180px]"></i>
             </div>
             <h3 className="text-xl font-black mb-10 flex items-center gap-4 tracking-tight">
               <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-900 flex items-center justify-center shadow-lg shadow-amber-400/20">
                 <i className="fa-solid fa-wand-magic-sparkles text-xl"></i>
               </div>
               Recomendações da Inteligência Artificial
             </h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {report.recommendations.map((rec, i) => (
                 <div key={i} className="flex gap-5 p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50 hover:border-blue-500/50 transition-all group">
                   <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center shrink-0 text-blue-400 font-black text-sm group-hover:bg-blue-600 group-hover:text-white transition-all shadow-inner">
                     {i + 1}
                   </div>
                   <p className="text-slate-300 text-sm leading-relaxed font-medium">{rec}</p>
                 </div>
               ))}
             </div>
          </div>
        </div>
      )}

      {!report && !loading && (
        <div className="text-center py-32 px-6">
          <div className="w-24 h-24 bg-white rounded-[32px] shadow-sm flex items-center justify-center mx-auto mb-6 text-slate-200 border border-slate-50 transition-transform hover:scale-105 duration-500">
            <i className="fa-solid fa-robot text-4xl"></i>
          </div>
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">Análise Pendente</h3>
          <p className="text-slate-400 max-w-sm mx-auto mt-2 text-sm font-medium">
            Clique no botão acima para iniciar sua primeira avaliação académica baseada em dados e tendências.
          </p>
        </div>
      )}
    </div>
  );
};

export default AiInsights;
