
import React, { useState, useMemo } from 'react';
import { Student } from '../types';
import { CLASSES_LIST, TRIMESTERS, SHIFTS } from '../constants';

interface ClassesDetailedViewProps {
  students: Student[];
}

type TabType = 'presence' | 'pauta' | 'boletim' | 'stats';

const TURMAS_LIST = Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i)); // A-Z
const DISCIPLINAS = ['Matemática', 'Português', 'História', 'Geografia', 'Ciências Naturais', 'Educação Física', 'Educação Visual'];

const ClassesDetailedView: React.FC<ClassesDetailedViewProps> = ({ students }) => {
  const [selectedTrimester, setSelectedTrimester] = useState(TRIMESTERS[0]);
  const [selectedClass, setSelectedClass] = useState(CLASSES_LIST[2]); // Default to 2ª Classe
  const [selectedShift, setSelectedShift] = useState(SHIFTS[0]);
  const [selectedTurma, setSelectedTurma] = useState(TURMAS_LIST[0]); // Default to Turma A
  const [activeTab, setActiveTab] = useState<TabType>('presence');
  const [isFinalPauta, setIsFinalPauta] = useState(false);
  
  // Dropdown states
  const [isClassDropdownOpen, setIsClassDropdownOpen] = useState(false);
  const [isShiftDropdownOpen, setIsShiftDropdownOpen] = useState(false);
  const [isTurmaDropdownOpen, setIsTurmaDropdownOpen] = useState(false);
  const [isDocDropdownOpen, setIsDocDropdownOpen] = useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = useState(false);
  
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  
  const [attendanceData, setAttendanceData] = useState<Record<string, boolean>>({});

  // Filtragem melhorada para considerar Classe e Turma
  const studentsInClass = students.filter(s => {
    const classMatch = s.grade.includes(selectedClass);
    const turmaMatch = s.grade.includes(`Turma ${selectedTurma}`);
    return classMatch && turmaMatch;
  });

  const handleFinalPauta = () => {
    setIsFinalPauta(true);
    setActiveTab('pauta');
    setIsClassDropdownOpen(false);
    setIsDocDropdownOpen(false);
    setIsTurmaDropdownOpen(false);
    setIsShiftDropdownOpen(false);
  };

  const handleTrimesterSelect = (t: typeof TRIMESTERS[0]) => {
    setIsFinalPauta(false);
    setSelectedTrimester(t);
  };

  const tabsInfo: Record<TabType, { label: string; icon: string }> = {
    presence: { label: 'Lista de Presença', icon: 'fa-calendar-check' },
    pauta: { label: isFinalPauta ? 'Pauta Final' : 'Pauta Trimestral', icon: 'fa-table-list' },
    boletim: { label: 'Boletim de Notas', icon: 'fa-id-card' },
    stats: { label: 'Estatísticas Gerais', icon: 'fa-chart-pie' }
  };

  const toggleAttendance = (studentId: string, day: number) => {
    const key = `${studentId}-${day}`;
    setAttendanceData(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleExport = (format: 'pdf' | 'excel' | 'csv') => {
    setIsExportDropdownOpen(false);
    setIsExporting(true);
    
    // Simulate generation delay
    setTimeout(() => {
      setIsExporting(false);
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
      console.log(`Exportando ${tabsInfo[activeTab].label} em formato ${format.toUpperCase()}`);
    }, 1500);
  };

  // Calculate days with majority attendance
  const majorityDays = useMemo(() => {
    const days = Array(31).fill(false);
    if (studentsInClass.length === 0) return days;
    
    for (let i = 0; i < 31; i++) {
      const day = i + 1;
      const presentCount = studentsInClass.filter(s => attendanceData[`${s.id}-${day}`]).length;
      if (presentCount > studentsInClass.length / 2) {
        days[i] = true;
      }
    }
    return days;
  }, [studentsInClass, attendanceData]);

  // Logic to calculate stats based on students in current filtered class
  const calculateGeneralStats = () => {
    const enrolledMF = studentsInClass.length;
    const enrolledF = studentsInClass.filter(s => s.gender === 'F').length;

    const evaluatedMF = enrolledMF; 
    const evaluatedF = enrolledF;

    const successMF = studentsInClass.filter(s => s.gpa >= 3.0).length;
    const successF = studentsInClass.filter(s => s.gender === 'F' && s.gpa >= 3.0).length;
    const successPerc = evaluatedMF > 0 ? ((successMF / evaluatedMF) * 100).toFixed(1) : '0.0';

    const failMF = evaluatedMF - successMF;
    const failF = evaluatedF - successF;
    const failPerc = evaluatedMF > 0 ? ((failMF / evaluatedMF) * 100).toFixed(1) : '0.0';

    const quitMF = studentsInClass.filter(s => s.status === 'Inactive').length;
    const quitF = studentsInClass.filter(s => s.gender === 'F' && s.status === 'Inactive').length;
    const quitPerc = enrolledMF > 0 ? ((quitMF / enrolledMF) * 100).toFixed(1) : '0.0';

    return {
      enrolledMF, enrolledF,
      evaluatedMF, evaluatedF,
      successMF, successF, successPerc,
      failMF, failF, failPerc,
      quitMF, quitF, quitPerc
    };
  };

  const genStats = calculateGeneralStats();

  const getSubjectStats = (subject: string) => {
    const total = studentsInClass.length;
    if (total === 0) return null;

    const evaluated = Math.max(0, total - Math.floor(Math.random() * 3));
    const notEvaluated = total - evaluated;
    
    const success = studentsInClass.filter(s => s.gpa >= 3.0).length;
    const failure = evaluated - success;
    const dropouts = studentsInClass.filter(s => s.status === 'Inactive').length;

    return {
      total,
      evaluated,
      notEvaluated,
      success,
      failure,
      dropouts,
      successPerc: evaluated > 0 ? ((success / evaluated) * 100).toFixed(1) : '0.0',
      failPerc: evaluated > 0 ? ((failure / evaluated) * 100).toFixed(1) : '0.0',
      quitPerc: total > 0 ? ((dropouts / total) * 100).toFixed(1) : '0.0'
    };
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto h-full flex flex-col">
      {/* Toast Notification for Export */}
      {exportSuccess && (
        <div className="fixed top-20 right-8 z-[100] bg-emerald-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-right-8 duration-500">
          <i className="fa-solid fa-circle-check"></i>
          <span className="text-xs font-black uppercase tracking-widest">Documento exportado com sucesso!</span>
        </div>
      )}

      {/* Top Controls Row */}
      <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between">
        <div className="flex flex-wrap gap-4 items-center">
          {/* Class Selector Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setIsClassDropdownOpen(!isClassDropdownOpen)}
              className="flex items-center gap-3 bg-white border border-slate-200 px-5 py-2.5 rounded-2xl shadow-sm hover:border-blue-400 transition-all group min-w-[180px]"
            >
              <i className="fa-solid fa-graduation-cap text-blue-600"></i>
              <div className="text-left">
                <p className="text-[10px] text-slate-400 font-bold uppercase leading-none mb-1">Classe</p>
                <p className="text-sm font-black text-slate-800 leading-none">{selectedClass}</p>
              </div>
              <i className={`fa-solid fa-chevron-down ml-auto text-slate-400 transition-transform ${isClassDropdownOpen ? 'rotate-180' : ''}`}></i>
            </button>

            {isClassDropdownOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setIsClassDropdownOpen(false)}></div>
                <div className="absolute top-full mt-2 left-0 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in zoom-in-95 duration-200 max-h-80 overflow-y-auto custom-scrollbar">
                  {CLASSES_LIST.map(cls => (
                    <button
                      key={cls}
                      onClick={() => { setSelectedClass(cls); setIsClassDropdownOpen(false); }}
                      className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                        selectedClass === cls ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {cls}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Turma Selector Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setIsTurmaDropdownOpen(!isTurmaDropdownOpen)}
              className="flex items-center gap-3 bg-white border border-slate-200 px-5 py-2.5 rounded-2xl shadow-sm hover:border-emerald-400 transition-all group min-w-[130px]"
            >
              <i className="fa-solid fa-chalkboard text-emerald-500"></i>
              <div className="text-left">
                <p className="text-[10px] text-slate-400 font-bold uppercase leading-none mb-1">Turma</p>
                <p className="text-sm font-black text-slate-800 leading-none">Turma {selectedTurma}</p>
              </div>
              <i className={`fa-solid fa-chevron-down ml-auto text-slate-400 transition-transform ${isTurmaDropdownOpen ? 'rotate-180' : ''}`}></i>
            </button>

            {isTurmaDropdownOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setIsTurmaDropdownOpen(false)}></div>
                <div className="absolute top-full mt-2 left-0 w-48 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in zoom-in-95 duration-200 max-h-80 overflow-y-auto custom-scrollbar">
                  <div className="grid grid-cols-2 gap-1 p-1">
                    {TURMAS_LIST.map(turma => (
                      <button
                        key={turma}
                        onClick={() => { setSelectedTurma(turma); setIsTurmaDropdownOpen(false); }}
                        className={`text-center px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                          selectedTurma === turma ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        Turma {turma}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Shift Selector Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setIsShiftDropdownOpen(!isShiftDropdownOpen)}
              className="flex items-center gap-3 bg-white border border-slate-200 px-5 py-2.5 rounded-2xl shadow-sm hover:border-indigo-400 transition-all group min-w-[140px]"
            >
              <i className={`fa-solid ${selectedShift.icon} text-indigo-500`}></i>
              <div className="text-left">
                <p className="text-[10px] text-slate-400 font-bold uppercase leading-none mb-1">Turno</p>
                <p className="text-sm font-black text-slate-800 leading-none">{selectedShift.name}</p>
              </div>
              <i className={`fa-solid fa-chevron-down ml-auto text-slate-400 transition-transform ${isShiftDropdownOpen ? 'rotate-180' : ''}`}></i>
            </button>

            {isShiftDropdownOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setIsShiftDropdownOpen(false)}></div>
                <div className="absolute top-full mt-2 left-0 w-48 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in zoom-in-95 duration-200">
                  {SHIFTS.map(shift => (
                    <button
                      key={shift.id}
                      onClick={() => { setSelectedShift(shift); setIsShiftDropdownOpen(false); }}
                      className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${
                        selectedShift.id === shift.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <i className={`fa-solid ${shift.icon}`}></i>
                      {shift.name}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Trimester Selector */}
        <div className="flex gap-2 p-1.5 bg-slate-200 rounded-2xl w-fit shrink-0">
          {TRIMESTERS.map(t => (
            <button
              key={t.id}
              onClick={() => handleTrimesterSelect(t)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                !isFinalPauta && selectedTrimester.id === t.id ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {t.name}
            </button>
          ))}
          <button 
            onClick={handleFinalPauta}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              isFinalPauta ? 'bg-rose-600 text-white shadow-sm' : 'text-rose-600 hover:bg-rose-50'
            }`}
          >
            PAUTA FINAL
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 flex-1 flex flex-col overflow-hidden">
        {/* Document Selection Dropdown */}
        <div className="px-6 border-b flex items-center justify-between h-16 bg-slate-50/50">
          <div className="relative">
            <button 
              onClick={() => setIsDocDropdownOpen(!isDocDropdownOpen)}
              className="flex items-center gap-4 bg-white border border-slate-200 px-6 py-2.5 rounded-2xl shadow-sm hover:border-blue-400 transition-all group min-w-[240px]"
            >
              <i className={`fa-solid ${tabsInfo[activeTab].icon} text-blue-600 text-lg`}></i>
              <div className="text-left">
                <p className="text-[10px] text-slate-400 font-bold uppercase leading-none mb-1">Documento Ativo</p>
                <p className="text-sm font-black text-slate-800 leading-none">{tabsInfo[activeTab].label}</p>
              </div>
              <i className={`fa-solid fa-chevron-down ml-auto text-slate-400 transition-transform ${isDocDropdownOpen ? 'rotate-180' : ''}`}></i>
            </button>

            {isDocDropdownOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setIsDocDropdownOpen(false)}></div>
                <div className="absolute top-full mt-2 left-0 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in zoom-in-95 duration-200">
                  {(['presence', 'pauta', 'boletim', 'stats'] as TabType[]).map(tabId => (
                    (!isFinalPauta || tabId !== 'presence') && (
                      <button
                        key={tabId}
                        onClick={() => { setActiveTab(tabId); setIsDocDropdownOpen(false); }}
                        className={`w-full text-left px-4 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-3 ${
                          activeTab === tabId ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <i className={`fa-solid ${tabsInfo[tabId].icon} w-5`}></i>
                        {tabsInfo[tabId].label}
                      </button>
                    )
                  ))}
                </div>
              </>
            )}
          </div>

          <div className="flex gap-2">
            <button className="hidden sm:flex items-center gap-2 bg-slate-100 text-slate-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-slate-200 transition-colors">
              <i className="fa-solid fa-print"></i>
              Imprimir
            </button>
            
            <div className="relative">
              <button 
                onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
                disabled={isExporting}
                className={`flex items-center gap-3 px-5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-xl active:scale-95 ${
                  isExporting ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-600/20'
                }`}
              >
                {isExporting ? (
                  <i className="fa-solid fa-circle-notch animate-spin"></i>
                ) : (
                  <i className="fa-solid fa-file-export"></i>
                )}
                <span className="hidden sm:inline">Exportar {tabsInfo[activeTab].label.split(' ')[0]}</span>
                <i className={`fa-solid fa-chevron-down text-[10px] transition-transform ${isExportDropdownOpen ? 'rotate-180' : ''}`}></i>
              </button>

              {isExportDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsExportDropdownOpen(false)}></div>
                  <div className="absolute top-full mt-3 right-0 w-64 bg-white rounded-[28px] shadow-2xl border border-slate-100 p-3 z-50 animate-in fade-in slide-in-from-top-4 duration-300">
                    <div className="px-4 py-3 mb-1">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Escolha o Formato</p>
                    </div>
                    
                    <button 
                      onClick={() => handleExport('excel')}
                      className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl hover:bg-emerald-50 text-left group transition-all"
                    >
                      <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-all">
                        <i className="fa-solid fa-file-excel"></i>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-black text-slate-800">Excel (.xlsx)</span>
                        <span className="text-[9px] text-slate-400 font-bold uppercase">Planilha de dados</span>
                      </div>
                    </button>

                    <button 
                      onClick={() => handleExport('pdf')}
                      className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl hover:bg-rose-50 text-left group transition-all mt-1"
                    >
                      <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-all">
                        <i className="fa-solid fa-file-pdf"></i>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-black text-slate-800">PDF (.pdf)</span>
                        <span className="text-[9px] text-slate-400 font-bold uppercase">Documento pronto a imprimir</span>
                      </div>
                    </button>

                    <button 
                      onClick={() => handleExport('csv')}
                      className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl hover:bg-blue-50 text-left group transition-all mt-1"
                    >
                      <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <i className="fa-solid fa-file-csv"></i>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-black text-slate-800">CSV (.csv)</span>
                        <span className="text-[9px] text-slate-400 font-bold uppercase">Formato bruto de dados</span>
                      </div>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Dynamic Content Area */}
        <div className="flex-1 p-6 overflow-y-auto custom-scrollbar">
          {activeTab === 'presence' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="flex flex-wrap gap-3">
                {selectedTrimester.months.map((m) => (
                  <button key={m} className="px-4 py-2 rounded-lg bg-blue-50 text-blue-700 text-[10px] font-bold uppercase hover:bg-blue-100 transition-colors border border-blue-100/50">
                    Mês de {m}
                  </button>
                ))}
              </div>
              <div className="border rounded-2xl overflow-x-auto shadow-inner bg-white custom-scrollbar">
                <table className="w-full text-xs min-w-[1200px]">
                  <thead className="bg-slate-50 border-b sticky top-0 z-10">
                    <tr>
                      <th className="px-4 py-4 text-left w-12 text-slate-400">Nº</th>
                      <th className="px-4 py-4 text-left min-w-[200px] border-r">Nome Completo</th>
                      {Array.from({length: 31}).map((_, i) => (
                        <th 
                          key={i} 
                          className={`px-0 py-4 text-center w-8 text-[9px] border-r font-black text-slate-500 transition-colors duration-500 ${majorityDays[i] ? 'bg-emerald-50/70 text-emerald-700' : ''}`}
                        >
                          {String(i + 1).padStart(2, '0')}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {studentsInClass.length > 0 ? studentsInClass.map((s, idx) => (
                      <tr key={s.id} className="hover:bg-blue-50/30 transition-colors">
                        <td className="px-4 py-3 font-bold text-slate-300 text-center">{idx+1}</td>
                        <td className="px-4 py-3 font-bold text-slate-700 border-r text-sm truncate">{s.name}</td>
                        {Array.from({length: 31}).map((_, i) => {
                          const day = i + 1;
                          const isPresent = attendanceData[`${s.id}-${day}`];
                          return (
                            <td 
                              key={i} 
                              className={`px-0 py-1 text-center border-r transition-colors duration-500 ${majorityDays[i] ? 'bg-emerald-50/30' : ''}`}
                            >
                              <button 
                                onClick={() => toggleAttendance(s.id, day)}
                                className={`w-6 h-6 rounded-md transition-all flex items-center justify-center mx-auto ${
                                  isPresent 
                                    ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' 
                                    : 'bg-slate-100 text-transparent hover:bg-slate-200 hover:text-slate-400'
                                }`}
                              >
                                <i className="fa-solid fa-check text-[10px]"></i>
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    )) : (
                      <tr><td colSpan={33} className="p-12 text-center text-slate-400 font-medium italic">Nenhum aluno encontrado.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'pauta' && (
            <div className="space-y-4 animate-in fade-in duration-300">
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-slate-800 flex items-center gap-2">
                  <i className="fa-solid fa-list-check text-blue-600"></i>
                  {isFinalPauta ? `Mapa Final de Notas - Ano Lectivo` : `Mapa de Notas - ${selectedTrimester.name}`}
                  <span className="ml-2 text-blue-600 bg-blue-50 px-2 py-0.5 rounded text-[10px] uppercase">{selectedClass} Turma {selectedTurma}</span>
                </h4>
              </div>
              <div className="border rounded-2xl overflow-hidden shadow-sm">
                <table className="w-full text-[10px]">
                  <thead className="bg-slate-50 text-slate-500 font-bold border-b uppercase tracking-tighter">
                    <tr>
                      <th className="px-4 py-3 text-left">Nº</th>
                      <th className="px-4 py-3 text-left">Nome do Aluno</th>
                      <th className="px-2 py-3 text-center border-l">Mat.</th>
                      <th className="px-2 py-3 text-center border-l">Port.</th>
                      <th className="px-2 py-3 text-center border-l">Hist.</th>
                      <th className="px-2 py-3 text-center border-l">Geog.</th>
                      <th className="px-2 py-3 text-center border-l">Ciên.</th>
                      <th className="px-2 py-3 text-center border-l bg-blue-50/50">Média</th>
                      <th className="px-2 py-3 text-center border-l">Obs.</th>
                      <th className="px-4 py-3 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {studentsInClass.map((s, idx) => (
                      <tr key={s.id} className="hover:bg-slate-50 group">
                        <td className="px-4 py-2 text-slate-400 font-medium">{idx+1}</td>
                        <td className="px-4 py-2 font-bold">{s.name}</td>
                        <td className="px-2 py-2 text-center border-l">14</td>
                        <td className="px-2 py-2 text-center border-l">12</td>
                        <td className="px-2 py-2 text-center border-l">13</td>
                        <td className="px-2 py-2 text-center border-l">11</td>
                        <td className="px-2 py-2 text-center border-l">15</td>
                        <td className="px-2 py-2 text-center border-l font-bold bg-blue-50/30 text-blue-700">{s.gpa.toFixed(1)}</td>
                        <td className="px-2 py-2 text-center border-l">
                          <span className={`text-[8px] font-bold uppercase ${s.gpa >= 3.0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {s.gpa >= 3.0 ? 'Aprovado' : 'Reprovado'}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-right">
                          <button className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all opacity-0 group-hover:opacity-100" title="Editar Nota">
                            <i className="fa-solid fa-pen-to-square text-xs"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'stats' && (
            <div className="animate-in fade-in duration-300 space-y-12">
              <div className="bg-slate-900 p-8 rounded-[32px] text-white overflow-hidden relative border-2 border-slate-800 shadow-2xl">
                 <div className="absolute top-0 right-0 p-8 opacity-10">
                   <i className="fa-solid fa-chart-line text-[140px]"></i>
                 </div>
                 <div className="relative z-10 text-center mb-10">
                   <h2 className="text-3xl font-black uppercase tracking-[0.2em] mb-2">{selectedTrimester.name}</h2>
                   <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Estatísticas Gerais de Frequência e Aproveitamento</p>
                   <div className="w-24 h-1 bg-blue-500 mx-auto rounded-full mt-4"></div>
                 </div>

                 <div className="overflow-x-auto">
                    <table className="w-full text-xs font-bold border-collapse border-2 border-slate-700">
                      <thead>
                        <tr className="bg-slate-800 border-b-2 border-slate-700">
                           <th colSpan={2} className="px-4 py-6 border-r-2 border-slate-700 text-center uppercase tracking-wider leading-relaxed">Nº de Alunos<br/>Matriculados</th>
                           <th colSpan={2} className="px-4 py-6 border-r-2 border-slate-700 text-center uppercase tracking-wider leading-relaxed">Nº de Alunos<br/>Avaliados</th>
                           <th colSpan={3} className="px-4 py-6 border-r-2 border-slate-700 text-center uppercase tracking-wider leading-relaxed">Alunos Com<br/>Aproveitamento</th>
                           <th colSpan={3} className="px-4 py-6 border-r-2 border-slate-700 text-center uppercase tracking-wider leading-relaxed">Alunos Sem<br/>Aproveitamento</th>
                           <th colSpan={3} className="px-4 py-6 text-center uppercase tracking-wider leading-relaxed">Alunos<br/>Desistentes</th>
                        </tr>
                        <tr className="bg-slate-800/50 border-b-2 border-slate-700">
                          <th className="px-2 py-2 border-r border-slate-700">MF</th><th className="px-2 py-2 border-r-2 border-slate-700">F</th>
                          <th className="px-2 py-2 border-r border-slate-700">MF</th><th className="px-2 py-2 border-r-2 border-slate-700">F</th>
                          <th className="px-2 py-2 border-r border-slate-700">MF</th><th className="px-2 py-2 border-r border-slate-700">F</th><th className="px-2 py-2 border-r-2 border-slate-700">%</th>
                          <th className="px-2 py-2 border-r border-slate-700">MF</th><th className="px-2 py-2 border-r border-slate-700">F</th><th className="px-2 py-2 border-r-2 border-slate-700">%</th>
                          <th className="px-2 py-2 border-r border-slate-700">MF</th><th className="px-2 py-2 border-r border-slate-700">F</th><th className="px-2 py-2">%</th>
                        </tr>
                      </thead>
                      <tbody className="bg-slate-900/40">
                        <tr className="border-b border-slate-700 group hover:bg-blue-600/10 transition-colors">
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black">{genStats.enrolledMF}</td>
                          <td className="px-4 py-6 border-r-2 border-slate-700 text-center text-xl font-black text-blue-400">{genStats.enrolledF}</td>
                          
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black">{genStats.evaluatedMF}</td>
                          <td className="px-4 py-6 border-r-2 border-slate-700 text-center text-xl font-black text-blue-400">{genStats.evaluatedF}</td>
                          
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black text-emerald-400">{genStats.successMF}</td>
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black text-emerald-300">{genStats.successF}</td>
                          <td className="px-4 py-6 border-r-2 border-slate-700 text-center text-xl font-black italic">{genStats.successPerc}%</td>
                          
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black text-rose-400">{genStats.failMF}</td>
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black text-rose-300">{genStats.failF}</td>
                          <td className="px-4 py-6 border-r-2 border-slate-700 text-center text-xl font-black italic">{genStats.failPerc}%</td>
                          
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black text-slate-500">{genStats.quitMF}</td>
                          <td className="px-4 py-6 border-r border-slate-700 text-center text-xl font-black text-slate-600">{genStats.quitF}</td>
                          <td className="px-4 py-6 text-center text-xl font-black italic">{genStats.quitPerc}%</td>
                        </tr>
                      </tbody>
                    </table>
                 </div>
              </div>

              {/* Subject Statistics Table */}
              <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-xl overflow-hidden relative">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h3 className="text-xl font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
                      <i className="fa-solid fa-book text-blue-600"></i>
                      Estatísticas Detalhadas por Disciplina
                    </h3>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Detalhamento individual de performance por área de saber</p>
                  </div>
                  <div className="px-4 py-2 bg-blue-50 text-blue-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-blue-100">
                    {DISCIPLINAS.length} Disciplinas
                  </div>
                </div>

                <div className="overflow-x-auto border rounded-[24px]">
                  <table className="w-full text-[11px] font-bold">
                    <thead className="bg-slate-50 text-slate-500 uppercase tracking-tighter border-b">
                      <tr>
                        <th className="px-6 py-4 text-left border-r">Disciplina</th>
                        <th className="px-4 py-4 text-center border-r">Matric.</th>
                        <th className="px-4 py-4 text-center border-r">Avaliados</th>
                        <th className="px-4 py-4 text-center border-r">Não Aval.</th>
                        <th className="px-4 py-4 text-center border-r text-emerald-600 bg-emerald-50/30">C/ Aproveit.</th>
                        <th className="px-4 py-4 text-center border-r text-rose-600 bg-rose-50/30">S/ Aproveit.</th>
                        <th className="px-4 py-4 text-center text-slate-400">Desist.</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {DISCIPLINAS.map(subject => {
                        const s = getSubjectStats(subject);
                        if (!s) return null;
                        return (
                          <tr key={subject} className="hover:bg-slate-50 transition-colors group">
                            <td className="px-6 py-4 border-r font-black text-slate-700">{subject}</td>
                            <td className="px-4 py-4 border-r text-center text-slate-500">{s.total}</td>
                            <td className="px-4 py-4 border-r text-center text-slate-800">{s.evaluated}</td>
                            <td className="px-4 py-4 border-r text-center text-amber-600">{s.notEvaluated}</td>
                            <td className="px-4 py-4 border-r text-center bg-emerald-50/20">
                              <span className="text-emerald-700 block">{s.success}</span>
                              <span className="text-[9px] text-emerald-500 font-black">{s.successPerc}%</span>
                            </td>
                            <td className="px-4 py-4 border-r text-center bg-rose-50/20">
                              <span className="text-rose-700 block">{s.failure}</span>
                              <span className="text-[9px] text-rose-500 font-black">{s.failPerc}%</span>
                            </td>
                            <td className="px-4 py-4 text-center">
                              <span className="text-slate-500 block">{s.dropouts}</span>
                              <span className="text-[9px] text-slate-400 font-black">{s.quitPerc}%</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm">
                   <h5 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                     <i className="fa-solid fa-circle-info text-blue-600"></i>
                     Resumo de Rendimento
                   </h5>
                   <div className="space-y-4">
                     <div className="flex justify-between items-center text-sm">
                       <span className="text-slate-500">Média Geral da Turma</span>
                       <span className="font-bold">13.4</span>
                     </div>
                     <div className="flex justify-between items-center text-sm">
                       <span className="text-slate-500">Maior Média</span>
                       <span className="font-bold text-emerald-600">18.2</span>
                     </div>
                     <div className="flex justify-between items-center text-sm">
                       <span className="text-slate-500">Menor Média</span>
                       <span className="font-bold text-rose-600">08.5</span>
                     </div>
                   </div>
                 </div>
                 <div className="p-6 bg-blue-50 border border-blue-100 rounded-3xl">
                   <h5 className="font-bold text-blue-800 mb-4">Ações Recomendadas</h5>
                   <ul className="text-xs text-blue-700 space-y-2 font-medium">
                     <li>• Agendar reuniões de conselho de notas.</li>
                     <li>• Notificar encarregados de alunos com média inferior a 10.</li>
                     <li>• Identificar necessidades de aulas extras de reforço.</li>
                   </ul>
                 </div>
              </div>
            </div>
          )}

          {activeTab === 'boletim' && (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in slide-in-from-bottom-4 duration-500">
                {studentsInClass.length > 0 ? studentsInClass.map(s => (
                  <div key={s.id} className="border p-5 rounded-3xl relative group hover:border-blue-400 hover:shadow-xl hover:shadow-blue-500/5 transition-all bg-white overflow-hidden">
                    <div className="absolute top-0 right-0 w-16 h-16 bg-blue-50 rounded-bl-full -mr-4 -mt-4 opacity-50 group-hover:bg-blue-600 group-hover:opacity-10 transition-all"></div>
                    <div className="flex items-center gap-4 mb-5">
                      <img src={s.avatar} className="w-14 h-14 rounded-2xl object-cover border-2 border-slate-50 shadow-sm" />
                      <div className="flex-1 min-w-0">
                        <h5 className="font-bold text-sm text-slate-800 truncate">{s.name}</h5>
                        <p className="text-[10px] text-slate-400 font-medium uppercase tracking-tighter">ID: {s.id} • {selectedClass} Turma {selectedTurma}</p>
                      </div>
                      <button className="text-blue-600 p-2 hover:bg-blue-50 rounded-xl transition-colors"><i className="fa-solid fa-print"></i></button>
                    </div>
                    <div className="space-y-1.5 text-[10px]">
                       <div className="p-2 bg-slate-50 rounded-xl flex justify-between items-center group-hover:bg-slate-100 transition-colors">
                         <span className="font-medium text-slate-500">Média Geral</span>
                         <span className="font-bold text-slate-800">{s.gpa.toFixed(1)}</span>
                       </div>
                       <div className="mt-4 p-3 bg-blue-600 text-white rounded-2xl flex justify-between items-center shadow-lg shadow-blue-600/20">
                         <span className="font-bold uppercase tracking-widest text-[8px]">Média Trimestral</span>
                         <span className="text-sm font-black">{s.gpa.toFixed(1)}</span>
                       </div>
                    </div>
                  </div>
                )) : (
                  <div className="col-span-full text-center py-20 text-slate-400 italic">Nenhum boletim disponível.</div>
                )}
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ClassesDetailedView;
