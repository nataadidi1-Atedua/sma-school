
import { Student, Teacher, Payment, School } from './types';

export const MOCK_SCHOOLS: School[] = [
  { id: 'S1', name: 'SM@ Luanda Academy', location: 'Luanda, Angola', type: 'Sede Central' },
  { id: 'S2', name: 'SM@ Benguela Primary', location: 'Benguela, Angola', type: 'Primária' },
  { id: 'S3', name: 'SM@ Huambo Tech', location: 'Huambo, Angola', type: 'Técnico-Profissional' },
  { id: 'S4', name: 'SM@ Lubango High', location: 'Lubango, Angola', type: 'Secundária' },
  { id: 'S5', name: 'SM@ Cabinda International', location: 'Cabinda, Angola', type: 'Internacional' },
  { id: 'S6', name: 'SM@ Namibe Oceanside', location: 'Moçâmedes, Angola', type: 'Primária' },
  { id: 'S7', name: 'SM@ Soyo Industrial', location: 'Soyo, Angola', type: 'Secundária' },
  { id: 'S8', name: 'SM@ Malanje Sunrise', location: 'Malanje, Angola', type: 'Primária' },
  { id: 'S9', name: 'SM@ Uíge Mountain', location: 'Uíge, Angola', type: 'Complexo Escolar' },
  { id: 'S10', name: 'SM@ Saurimo Diamond', location: 'Saurimo, Angola', type: 'Primária' },
  { id: 'S11', name: 'SM@ Kuito Resilience', location: 'Kuito, Angola', type: 'Secundária' },
  { id: 'S12', name: 'SM@ Caxito Green', location: 'Caxito, Angola', type: 'Primária' },
];

export const MOCK_STUDENTS: Student[] = [
  // Added required birthDate to each student mock data entry
  { id: '101', name: 'Baltazar Gongo', email: 'b.gongo@school.edu', grade: '2ª Classe - Turma A', status: 'Active', gpa: 3.5, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/bgongo/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'M', schoolId: 'S1', birthDate: '2016-05-15' },
  { id: '102', name: 'Machado Armando', email: 'm.armando@school.edu', grade: '2ª Classe - Turma A', status: 'Active', gpa: 3.2, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/marmando/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'M', schoolId: 'S1', birthDate: '2016-06-20' },
  { id: '104', name: 'Cuimão Gonsalves', email: 'c.gonsalves@school.edu', grade: '2ª Classe - Turma A', status: 'Active', gpa: 3.0, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/cgonsalves/150', paymentStatus: 'Pending', enrollmentDate: '2023-09-01', gender: 'M', schoolId: 'S1', birthDate: '2016-07-10' },
  { id: '204', name: 'Helena Guilhermina', email: 'h.guilhermina@school.edu', grade: '2ª Classe - Turma B', status: 'Active', gpa: 3.9, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/hguilh/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'F', schoolId: 'S1', birthDate: '2016-08-05' },
  { id: '205', name: 'Quileba Indira', email: 'q.indira@school.edu', grade: '2ª Classe - Turma B', status: 'Active', gpa: 3.5, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/qindir/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'F', schoolId: 'S1', birthDate: '2016-09-12' },
  { id: '207', name: 'Isabel Jacinto Augusto', email: 'i.augusto@school.edu', grade: '2ª Classe - Turma B', status: 'Active', gpa: 3.7, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/iaugust/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'F', schoolId: 'S1', birthDate: '2016-10-25' },
  { id: '301', name: 'Capemba Isabel', email: 'c.isabel@school.edu', grade: '3ª Classe - Turma B', status: 'Active', gpa: 3.3, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/cisabel/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'F', schoolId: 'S1', birthDate: '2015-04-10' },
  { id: '1', name: 'Alice Johnson', email: 'alice.j@school.edu', grade: '10ª Classe', status: 'Active', gpa: 3.8, lastAttendance: '2023-10-25', avatar: 'https://picsum.photos/seed/alice/150', paymentStatus: 'Paid', enrollmentDate: '2023-09-01', gender: 'F', schoolId: 'S2', birthDate: '2008-03-22' },
];

export const MOCK_TEACHERS: Teacher[] = [
  { id: 'T1', name: 'Dr. Sarah Connor', subject: 'Mathematics', email: 's.connor@school.edu', classes: ['Algebra I', 'Calculus AB'], avatar: 'https://picsum.photos/seed/sarah/150', schoolId: 'S1' },
  { id: 'T2', name: 'Prof. James Hook', subject: 'History', email: 'j.hook@school.edu', classes: ['World History', 'Ethics'], avatar: 'https://picsum.photos/seed/james/150', schoolId: 'S1' },
];

export const MOCK_PAYMENTS: Payment[] = [
  { id: 'P1', studentId: '101', studentName: 'Baltazar Gongo', amount: 500, date: '2023-10-05', month: 'October', type: 'Tuition', status: 'Completed', schoolId: 'S1' },
];

export const CLASSES_LIST = [
  'Iniciação', 
  '1ª Classe', '2ª Classe', '3ª Classe', '4ª Classe', '5ª Classe', '6ª Classe',
  '7ª Classe', '8ª Classe', '9ª Classe', '10ª Classe', '11ª Classe', '12ª Classe', '13ª Classe'
];

export const SHIFTS = [
  { id: 'morning', name: 'Manhã', icon: 'fa-sun' },
  { id: 'afternoon', name: 'Tarde', icon: 'fa-cloud-sun' },
  { id: 'night', name: 'Noite', icon: 'fa-moon' }
];

export const TRIMESTERS = [
  { id: 1, name: '1º Trimestre', months: ['Setembro', 'Outubro', 'Novembro'] },
  { id: 2, name: '2º Trimestre', months: ['Janeiro', 'Fevereiro', 'Março'] },
  { id: 3, name: '3º Trimestre', months: ['Abril', 'Maio', 'Junho'] },
];

export const ATTENDANCE_DATA = [
  { name: 'Mon', attendance: 92 },
  { name: 'Tue', attendance: 95 },
  { name: 'Wed', attendance: 88 },
  { name: 'Thu', attendance: 94 },
  { name: 'Fri', attendance: 90 },
];

export const PERFORMANCE_DATA = [
  { name: 'Math', avg: 85 },
  { name: 'Science', avg: 78 },
  { name: 'History', avg: 92 },
  { name: 'Arts', avg: 88 },
  { name: 'PE', avg: 95 },
];
