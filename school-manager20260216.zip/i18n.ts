
export type Locale = 'pt' | 'en' | 'es' | 'fr' | 'it' | 'jp' | 'zh' | 'de' | 'ru' | 'ar';

export const LANGUAGES: { code: Locale; name: string; flag: string }[] = [
  { code: 'pt', name: 'Português', flag: '🇵🇹' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹' },
  { code: 'jp', name: '日本語', flag: '🇯🇵' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
];

export const translations: Record<Locale, any> = {
  pt: {
    dashboard: 'Dashboard', direction: 'Direção', secretary: 'Secretaria', finance: 'Finanças', 
    classes: 'Classes & Turmas', students: 'Alunos', teachers: 'Professores', ai: 'IA Acadêmica', 
    settings: 'Definições', totalStudents: 'Total Estudantes', avgGpa: 'Média GPA', active: 'Ativos',
    search: 'Procurar alunos, turmas...', languagesTitle: '10 Idiomas mais falados', logout: 'Terminar Sessão'
  },
  en: {
    dashboard: 'Dashboard', direction: 'Direction', secretary: 'Secretary', finance: 'Finance', 
    classes: 'Classes & Groups', students: 'Students', teachers: 'Teachers', ai: 'Academic AI', 
    settings: 'Settings', totalStudents: 'Total Students', avgGpa: 'Avg GPA', active: 'Active',
    search: 'Search students, classes...', languagesTitle: 'Top 10 Spoken Languages', logout: 'Logout'
  },
  es: {
    dashboard: 'Tablero', direction: 'Dirección', secretary: 'Secretaría', finance: 'Finanzas', 
    classes: 'Clases y Grupos', students: 'Estudiantes', teachers: 'Profesores', ai: 'IA Académica', 
    settings: 'Ajustes', totalStudents: 'Total Estudiantes', avgGpa: 'GPA Promedio', active: 'Activos',
    search: 'Buscar...', languagesTitle: 'Los 10 idiomas más hablados', logout: 'Cerrar sesión'
  },
  fr: {
    dashboard: 'Tableau de bord', direction: 'Direction', secretary: 'Secrétariat', finance: 'Finances', 
    classes: 'Classes et Groupes', students: 'Étudiants', teachers: 'Enseignants', ai: 'IA Académique', 
    settings: 'Paramètres', totalStudents: 'Total Étudiants', avgGpa: 'Moyenne GPA', active: 'Actifs',
    search: 'Rechercher...', languagesTitle: 'Top 10 des langues parlées', logout: 'Déconnexion'
  },
  it: {
    dashboard: 'Dashboard', direction: 'Direzione', secretary: 'Segreteria', finance: 'Finanza', 
    classes: 'Classi e Gruppi', students: 'Studenti', teachers: 'Insegnanti', ai: 'IA Accademica', 
    settings: 'Impostazioni', totalStudents: 'Studenti Totali', avgGpa: 'Media GPA', active: 'Attivi',
    search: 'Cerca...', languagesTitle: 'Le 10 lingue più parlate', logout: 'Disconnetti'
  },
  jp: {
    dashboard: 'ダッシュボード', direction: '管理', secretary: '事務局', finance: '財務', 
    classes: 'クラスとグループ', students: '学生', teachers: '教師', ai: 'アカデミックAI', 
    settings: '設定', totalStudents: '全学生数', avgGpa: '平均GPA', active: 'アクティブ',
    search: '検索...', languagesTitle: '世界で最も話されている10の言語', logout: 'ログアウト'
  },
  zh: {
    dashboard: '仪表板', direction: '领导层', secretary: '秘书处', finance: '财务', 
    classes: '班级与小组', students: '学生', teachers: '教师', ai: '学术人工智能', 
    settings: '设置', totalStudents: '学生总数', avgGpa: '平均绩点', active: '在校',
    search: '搜索...', languagesTitle: '世界上最常用的10种语言', logout: '退出登录'
  },
  de: {
    dashboard: 'Dashboard', direction: 'Leitung', secretary: 'Sekretariat', finance: 'Finanzen', 
    classes: 'Klassen & Gruppen', students: 'Schüler', teachers: 'Lehrer', ai: 'Akademische KI', 
    settings: 'Einstellungen', totalStudents: 'Gesamtschüler', avgGpa: 'Durchschnitts-GPA', active: 'Aktiv',
    search: 'Suche...', languagesTitle: 'Top 10 der meistgesprochenen Sprachen', logout: 'Abmelden'
  },
  ru: {
    dashboard: 'Панель', direction: 'Дирекция', secretary: 'Секретариат', finance: 'Финансы', 
    classes: 'Классы и группы', students: 'Ученики', teachers: 'Учителя', ai: 'Академический ИИ', 
    settings: 'Настройки', totalStudents: 'Всего учеников', avgGpa: 'Средний балл', active: 'Активные',
    search: 'Поиск...', languagesTitle: '10 самых распространенных языков', logout: 'Выйти'
  },
  ar: {
    dashboard: 'لوحة القيادة', direction: 'الإدارة', secretary: 'السكرتارية', finance: 'المالية', 
    classes: 'الفصول والمجموعات', students: 'الطلاب', teachers: 'المعلمون', ai: 'الذكاء الاصطناعي الأكاديمي', 
    settings: 'الإعدادات', totalStudents: 'إجمالي الطلاب', avgGpa: 'معدل تراكمي', active: 'نشط',
    search: 'بحث...', languagesTitle: 'أكثر 10 لغات انتشاراً في العالم', logout: 'تسجيل الخروج'
  }
};
