
export enum ViewType {
  DASHBOARD = 'DASHBOARD',
  STUDENTS = 'STUDENTS',
  TEACHERS = 'TEACHERS',
  DIRECTION = 'DIRECTION',
  SECRETARY = 'SECRETARY',
  FINANCE = 'FINANCE',
  CLASSES_DETAILED = 'CLASSES_DETAILED',
  AI_INSIGHTS = 'AI_INSIGHTS',
  SETTINGS = 'SETTINGS'
}

export interface School {
  id: string;
  name: string;
  location: string;
  type: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  grade: string;
  status: 'Active' | 'Inactive';
  gpa: number;
  lastAttendance: string;
  avatar: string;
  paymentStatus: 'Paid' | 'Pending' | 'Overdue';
  enrollmentDate: string;
  gender: 'M' | 'F';
  schoolId: string;
  birthDate: string;
  shift?: string;
  room?: string;
  turma?: string;
  familyInfo?: {
    fatherName: string;
    motherName: string;
    emergencyContact: string;
    emergencyPhone: string;
  };
  medicalInfo?: {
    bloodType: string;
    allergies: string;
    conditions: string;
  };
  locationInfo?: {
    address: string;
    neighborhood: string;
    city: string;
  };
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  email: string;
  classes: string[];
  avatar: string;
  schoolId: string;
}

export interface StaffAssiduity {
  id: string;
  name: string;
  role: string;
  presenceDays: number;
  absences: number;
  lateArrivals: number;
  earlyDepartures: number;
  justified: number;
  unjustified: number;
  punctualityScore: number;
  globalIndex: number;
  avatar: string;
}

export interface Payment {
  id: string;
  studentId: string;
  studentName: string;
  amount: number;
  date: string;
  month: string;
  type: 'Tuition' | 'Enrollment' | 'Other';
  status: 'Completed' | 'Pending';
  schoolId: string;
}

export interface InsightReport {
  summary: string;
  recommendations: string[];
  riskStudents: string[];
  topPerformers: string[];
}

export interface CurriculumSuggestion {
  subject: string;
  topic: string;
  reason: string;
  suggestedMaterials: string[];
}
