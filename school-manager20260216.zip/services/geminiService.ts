
import { GoogleGenAI, Type } from "@google/genai";
import { Student } from "../types";

// Always use the named parameter and process.env.API_KEY directly
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAcademicInsights = async (students: Student[]) => {
  const studentSummary = students.map(s => `${s.name} (GPA: ${s.gpa}, Grade: ${s.grade}, Status: ${s.status})`).join(', ');
  
  const prompt = `Analyze the following student performance data and provide academic insights for school administration.
  Data: ${studentSummary}
  
  Provide a detailed report in JSON format with:
  1. A general summary of school performance.
  2. Actionable recommendations for the principal.
  3. A list of students potentially at risk (GPA < 3.0 or Inactive).
  4. Top performers.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
            riskStudents: { type: Type.ARRAY, items: { type: Type.STRING } },
            topPerformers: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["summary", "recommendations", "riskStudents", "topPerformers"]
        }
      }
    });

    // Use .text property directly
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return {
      summary: "Error generating AI insights.",
      recommendations: [],
      riskStudents: [],
      topPerformers: []
    };
  }
};

export const getCurriculumSuggestions = async (students: Student[]) => {
  const data = students.map(s => `Name: ${s.name}, GPA: ${s.gpa}, Grade: ${s.grade}`).join('; ');
  const prompt = `Based on the following student performance data, suggest curriculum adjustments and personalized learning materials.
  Data: ${data}
  
  Return a JSON array of suggestions with the following structure:
  [
    {
      "subject": "Subject Name",
      "topic": "Topic that needs focus",
      "reason": "Why this is suggested based on data",
      "suggestedMaterials": ["Material 1", "Material 2"]
    }
  ]`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              subject: { type: Type.STRING },
              topic: { type: Type.STRING },
              reason: { type: Type.STRING },
              suggestedMaterials: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["subject", "topic", "reason", "suggestedMaterials"]
          }
        }
      }
    });
    // Use .text property directly
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini Curriculum Error:", error);
    return [];
  }
};

export const getTopLanguages = async () => {
  const prompt = "List the 10 most spoken languages in the world with their approximate number of speakers and a very brief interesting fact about each. Return as a JSON array of objects with keys: rank, language, speakers, and fact.";
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              rank: { type: Type.NUMBER },
              language: { type: Type.STRING },
              speakers: { type: Type.STRING },
              fact: { type: Type.STRING }
            },
            required: ["rank", "language", "speakers", "fact"]
          }
        }
      }
    });
    // Use .text property directly
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini Languages Error:", error);
    return [];
  }
};
