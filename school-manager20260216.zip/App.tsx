
import React, { useState, useEffect } from 'react';
import { ViewType, Student, Teacher, School } from './types';
import { MOCK_STUDENTS, MOCK_TEACHERS, MOCK_SCHOOLS } from './constants';
import { Locale, translations } from './i18n';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardView from './components/DashboardView';
import StudentManagement from './components/StudentManagement';
import TeacherManagement from './components/TeacherManagement';
import AiInsights from './components/AiInsights';
import SecretaryView from './components/SecretaryView';
import FinanceView from './components/FinanceView';
import ClassesDetailedView from './components/ClassesDetailedView';
import DirectionView from './components/DirectionView';
import ProfileModal from './components/ProfileModal';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>(ViewType.DASHBOARD);
  const [locale, setLocale] = useState<Locale>('pt');
  const [schools, setSchools] = useState<School[]>(MOCK_SCHOOLS);
  const [currentSchool, setCurrentSchool] = useState<School>(MOCK_SCHOOLS[0]);
  const [students, setStudents] = useState<Student[]>(MOCK_STUDENTS);
  const [teachers, setTeachers] = useState<Teacher[]>(MOCK_TEACHERS);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [userAvatar, setUserAvatar] = useState('https://picsum.photos/seed/admin/40');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  
  // Auth States
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  useEffect(() => {
    setIsSidebarOpen(false);
  }, [currentView]);

  const filteredStudents = students.filter(s => s.schoolId === currentSchool.id);
  const filteredTeachers = teachers.filter(t => t.schoolId === currentSchool.id);

  const t = translations[locale];

  const handleUpdateSchool = (updatedSchool: School) => {
    setSchools(prev => prev.map(s => s.id === updatedSchool.id ? updatedSchool : s));
    if (currentSchool.id === updatedSchool.id) {
      setCurrentSchool(updatedSchool);
    }
  };

  const handleAddSchool = (newSchool: School) => {
    setSchools(prev => [...prev, newSchool]);
  };

  const renderView = () => {
    switch (currentView) {
      case ViewType.DASHBOARD:
        return <DashboardView students={filteredStudents} teachers={filteredTeachers} locale={locale} schoolName={currentSchool.name} />;
      case ViewType.DIRECTION:
        return (
          <DirectionView 
            students={filteredStudents} 
            currentSchool={currentSchool} 
            onUpdateSchool={handleUpdateSchool}
            onAddSchool={handleAddSchool}
          />
        );
      case ViewType.SECRETARY:
        return <SecretaryView students={filteredStudents} setStudents={setStudents} schoolId={currentSchool.id} />;
      case ViewType.FINANCE:
        return <FinanceView students={filteredStudents} />;
      case ViewType.CLASSES_DETAILED:
        return <ClassesDetailedView students={filteredStudents} />;
      case ViewType.STUDENTS:
        return <StudentManagement students={filteredStudents} setStudents={setStudents} />;
      case ViewType.TEACHERS:
        return <TeacherManagement teachers={filteredTeachers} setTeachers={setTeachers} />;
      case ViewType.AI_INSIGHTS:
        return <AiInsights students={filteredStudents} />;
      case ViewType.SETTINGS:
        return (
          <div className="p-8">
            <h2 className="text-2xl font-bold mb-4 text-slate-800">{t.settings}</h2>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 max-w-2xl">
              <div className="space-y-6">
                <section>
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">Preferências</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                      <span className="text-sm font-medium">Notificações por Email</span>
                      <input type="checkbox" defaultChecked className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                      <span className="text-sm font-medium">Backup Automático</span>
                      <input type="checkbox" defaultChecked className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                    </div>
                  </div>
                </section>
                <div className="p-4 bg-amber-50 text-amber-800 rounded-xl text-sm flex gap-3">
                  <i className="fa-solid fa-triangle-exclamation mt-0.5"></i>
                  <p>A chave da API Gemini está configurada no ambiente. Não partilhe as suas credenciais de acesso.</p>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return <DashboardView students={filteredStudents} teachers={filteredTeachers} locale={locale} schoolName={currentSchool.name} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden" 
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Auth Modals */}
      {(showLogin || showRegister) && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[32px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="relative p-8">
              <button 
                onClick={() => { setShowLogin(false); setShowRegister(false); }}
                className="absolute top-6 right-6 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>

              <div className="mb-8">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 ${showLogin ? 'bg-blue-600' : 'bg-emerald-600'} text-white text-2xl shadow-lg`}>
                  <i className={`fa-solid ${showLogin ? 'fa-fingerprint' : 'fa-user-plus'}`}></i>
                </div>
                <h3 className="text-2xl font-black text-slate-800 tracking-tight">
                  {showLogin ? 'Bem-vindo de Volta' : 'Criar Conta Acadêmica'}
                </h3>
                <p className="text-sm text-slate-500">
                  {showLogin ? 'Aceda ao seu painel administrativo' : 'Registe-se como novo colaborador ou encarregado'}
                </p>
              </div>

              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                {showRegister && (
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Nome Completo</label>
                    <input type="text" placeholder="Seu nome aqui" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm" />
                  </div>
                )}
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Endereço de Email</label>
                  <input type="email" placeholder="nome@exemplo.com" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Palavra-passe</label>
                  <input type="password" placeholder="••••••••" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm" />
                </div>

                <button className={`w-full py-4 rounded-2xl font-black uppercase text-xs tracking-widest text-white shadow-xl transition-all active:scale-95 ${showLogin ? 'bg-blue-600 shadow-blue-600/20 hover:bg-blue-700' : 'bg-emerald-600 shadow-emerald-600/20 hover:bg-emerald-700'}`}>
                  {showLogin ? 'Iniciar Sessão' : 'Concluir Registo'}
                </button>
              </form>

              <div className="mt-8 pt-6 border-t border-slate-100 text-center">
                <p className="text-sm text-slate-500">
                  {showLogin ? 'Astill não tem conta?' : 'Já tem uma conta?'}
                  <button 
                    onClick={() => { setShowLogin(!showLogin); setShowRegister(!showRegister); }}
                    className="ml-2 font-black text-blue-600 hover:underline underline-offset-4"
                  >
                    {showLogin ? 'Registe-se agora' : 'Faça login aqui'}
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        isOpen={isSidebarOpen}
        closeSidebar={() => setIsSidebarOpen(false)}
        locale={locale}
        schools={schools}
        currentSchool={currentSchool}
        setCurrentSchool={setCurrentSchool}
        userAvatar={userAvatar}
        onProfileClick={() => setIsProfileModalOpen(true)}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title={currentView} 
          openSidebar={() => setIsSidebarOpen(true)}
          locale={locale}
          setLocale={setLocale}
          onLoginClick={() => setShowLogin(true)}
          onRegisterClick={() => setShowRegister(true)}
        />
        <main className="flex-1 overflow-y-auto bg-slate-50 custom-scrollbar">
          {renderView()}
        </main>
      </div>

      <ProfileModal 
        isOpen={isProfileModalOpen} 
        onClose={() => setIsProfileModalOpen(false)} 
        currentAvatar={userAvatar} 
        onSave={(newImg) => {
          setUserAvatar(newImg);
          setIsProfileModalOpen(false);
        }} 
      />
    </div>
  );
};

export default App;
